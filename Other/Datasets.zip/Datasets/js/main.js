const sharp = require('sharp');
const path = require('path');
const fs = require('fs');

const ConfigManager = require('./modules/config');
const EarthEngineManager = require('./modules/earth-engine');
const { GridProcessor } = require('./modules/grid-processor');
const DataDownloader = require('./modules/data-downloader');
const MetadataManager = require('./modules/metadata-manager');
const ProgressTracker = require('./modules/progress-tracker');
const FileUtils = require('./modules/file-utils');

class EnhancedPipeline {
  constructor() {
    this.config = null;
    this.earthEngine = null;
    this.gridProcessor = null;
    this.dataDownloader = null;
    this.metadataManager = null;
    this.progressTracker = null;
    this.fileUtils = null;
    this.outputDir = null;
    this.startTime = null;
  }

  async initialize() {
    try {
      console.log('🚀 Enhanced Earth Engine Pipeline');
      console.log('='.repeat(50));

      this.config = new ConfigManager('./config.json');
      console.log(`📍 Area: ${this.config.get('area.name')}`);

      this.earthEngine = new EarthEngineManager();
      await this.earthEngine.initialize();

      this.gridProcessor = new GridProcessor(this.config, this.earthEngine);
      this.dataDownloader = new DataDownloader(this.config, this.earthEngine);
      this.metadataManager = new MetadataManager(this.config);
      this.fileUtils = new FileUtils(this.config);

      this.outputDir = this.config.createOutputStructure();
      console.log(`📁 Output: ${this.outputDir}`);

    } catch (error) {
      console.error('❌ Pipeline initialization failed:', error.message);
      throw error;
    }
  }

  async run() {
    try {
      this.startTime = Date.now();

      console.log('🌍 Starting Enhanced Large Area Processing');
      console.log('='.repeat(60));

      const areaInfo = this.config.getAreaInfo();
      const cells = await this.gridProcessor.generateGrid(areaInfo.polygon);
      const gridAnalysis = this.gridProcessor.getGridAnalysis();

      this.progressTracker = new ProgressTracker(cells.length);
      this.printGridInfo(gridAnalysis, cells);

      await this.processCellsBatched(cells);
      await this.handleRetries(cells);

      const processingStats = this.progressTracker.getDetailedStats();
      await this.generateFinalSummary(cells, gridAnalysis, processingStats);

      this.printCompletionReport(cells, processingStats);

    } catch (error) {
      console.error('❌ Pipeline execution failed:', error.message);
      throw error;
    }
  }

  async processCellsBatched(cells) {
    const processConfig = this.config.getProcessingConfig();
    const performanceConfig = this.config.getPerformanceConfig();

    if (!performanceConfig.enableBatching) {
      return await this.processCellsSequential(cells);
    }

    const batches = this.gridProcessor.createBatches(performanceConfig.batchSize);
    console.log(`🔄 Processing ${cells.length} cells in ${batches.length} batches`);
    console.log(`📊 Batch size: ${performanceConfig.batchSize} | Concurrent: ${processConfig.concurrentCells}`);

    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      console.log(`\n${'='.repeat(60)}`);
      console.log(`🔄 BATCH ${i + 1}/${batches.length} - Processing ${batch.length} cells`);
      console.log(`${'='.repeat(60)}`);

      this.progressTracker.startBatch(i + 1, batch.length);

      if (processConfig.concurrentCells > 1 && batch.length > 1) {
        await this.processBatchConcurrent(batch, processConfig.concurrentCells);
      } else {
        await this.processBatchSequential(batch);
      }

      this.progressTracker.completeBatch();
      this.progressTracker.printProgress();

      if (i < batches.length - 1 && processConfig.delayBetweenBatches > 0) {
        console.log(`⏳ Batch delay: ${processConfig.delayBetweenBatches}ms`);
        await this.delay(processConfig.delayBetweenBatches);
      }
    }
  }

  async processBatchConcurrent(batch, concurrency) {
    const chunks = this.chunkArray(batch, concurrency);

    for (const chunk of chunks) {
      const promises = chunk.map(cell => this.processCell(cell));
      await Promise.allSettled(promises);

      if (chunk !== chunks[chunks.length - 1]) {
        await this.delay(1000);
      }
    }
  }

  async processBatchSequential(batch) {
    for (const cell of batch) {
      await this.processCell(cell);
    }
  }

  // ✅ Core cell processing with heatmap + no weather
  async processCell(cell) {
    const cellTracker = this.progressTracker.startCell(cell.id);
    const processConfig = this.config.getProcessingConfig();

    try {
      console.log(`\n🔲 Processing Cell ${cell.id}`);
      console.log(`   📍 Center: ${cell.getCenter().join(', ')} | Area: ${cell.areaKm2.toFixed(1)} km²`);

      cell.outputDir = this.fileUtils.createCellOutputDir(cell.id, this.outputDir);

      if (processConfig.skipExisting) {
        const existing = this.fileUtils.checkExistingData(cell.outputDir);
        if (existing.sensor && existing.metadata) {
          console.log(`   ⏭️ Skipping - required data exists`);
          this.progressTracker.skipCell(cell.id);
          return;
        }
      }

      let satelliteResult = null;
      let sensorResult = null;
      let weatherResult = null;

      // ✅ Satellite download + heatmap conversion
      if (!this.fileUtils.checkExistingData(cell.outputDir).satellite) {
        this.progressTracker.startSatelliteDownload(cellTracker);
        try {
          satelliteResult = await this.dataDownloader.downloadSatelliteData(cell, cell.outputDir);
          this.progressTracker.completeSatelliteDownload(cellTracker, true, satelliteResult.fileSize);

          if (satelliteResult && satelliteResult.filePath) {
            await this.convertTiffToHeatmapPNG(satelliteResult.filePath, cell.outputDir);
            fs.unlinkSync(satelliteResult.filePath);
            console.log(`🧹 Deleted original satellite.tif after PNG generation`);
          }

        } catch (error) {
          this.progressTracker.completeSatelliteDownload(cellTracker, false);
          console.log(`   ❌ Satellite failed: ${error.message}`);
        }
      }

      await this.delay(processConfig.delayBetweenCells);

      // ✅ Sensor data download
      if (!this.fileUtils.checkExistingData(cell.outputDir).sensor) {
        this.progressTracker.startSensorDownload(cellTracker);
        try {
          sensorResult = await this.dataDownloader.downloadSensorData(cell, cell.outputDir);
          this.progressTracker.completeSensorDownload(cellTracker, true, sensorResult.fileSize);
        } catch (error) {
          this.progressTracker.completeSensorDownload(cellTracker, false);
          console.log(`   ❌ Sensor failed: ${error.message}`);
        }
      }

      await this.delay(processConfig.delayBetweenCells);

      // ✅ Metadata generation (no weather)
      try {
        const metadataResult = this.metadataManager.createCellMetadata(
          cell,
          satelliteResult,
          sensorResult,
          cell.outputDir,
          null
        );
        cell.metadata = metadataResult.metadata;
      } catch (error) {
        console.log(`   ⚠️ Metadata creation failed: ${error.message}`);
      }

      const processingTime = Date.now() - cellTracker.startTime;
      cell.markSuccess(satelliteResult, sensorResult, processingTime);
      this.progressTracker.completeCell(cellTracker, true);
      console.log(`   ✅ Cell ${cell.id} completed`);

    } catch (error) {
      cell.markError(error.message);
      this.progressTracker.completeCell(cellTracker, false, error.message);
      console.error(`   ❌ Cell ${cell.id} failed: ${error.message}`);
    }
  }

  // ✅ TIFF → PNG
  async convertTiffToHeatmapPNG(tiffPath, outputDir, outputName = 'heatmap') {
    try {
      const pngPath = path.join(outputDir, `${outputName}.png`);

      await sharp(tiffPath)
        .resize(800)
        .toColourspace('b-w')
        .png()
        .toFile(pngPath);

      console.log(`🌡️ Heatmap PNG generated at: ${pngPath}`);
      return pngPath;

    } catch (error) {
      console.error('❌ Failed to convert TIFF to heatmap PNG:', error);
      throw error;
    }
  }

  async handleRetries(cells) {
    const retryableCells = this.gridProcessor.getRetryableCells();
    if (retryableCells.length === 0) return;

    console.log(`\n🔄 Retrying ${retryableCells.length} failed cells`);
    console.log('='.repeat(60));

    for (let i = 0; i < retryableCells.length; i++) {
      const cell = retryableCells[i];
      console.log(`\n🔄 RETRY ${i + 1}/${retryableCells.length}: Cell ${cell.id}`);
      cell.reset();
      await this.processCell(cell);

      const processConfig = this.config.getProcessingConfig();
      if (processConfig.retryDelayMs > 0) {
        await this.delay(processConfig.retryDelayMs);
      }
    }
  }

  async generateFinalSummary(cells, gridAnalysis, processingStats) {
    try {
      console.log('\n📊 Generating final summary...');

      const summaryResult = this.metadataManager.createProcessingSummary(
        cells,
        gridAnalysis,
        processingStats,
        this.outputDir
      );

      const manifest = this.fileUtils.createFileManifest(
        this.outputDir,
        `${this.outputDir}/file_manifest.json`
      );

      console.log(`📋 Files manifest: ${manifest.summary.totalFiles} files, ${manifest.summary.totalSizeMB} MB`);
    } catch (error) {
      console.error(`❌ Failed to generate summary: ${error.message}`);
    }
  }

  printGridInfo(gridAnalysis, cells) {
    if (gridAnalysis.isSingleCell) {
      console.log(`🔲 Single cell mode (${gridAnalysis.totalAreaKm2.toFixed(1)} km²)`);
    } else {
      console.log(`📊 Grid: ${gridAnalysis.gridSize.rows}×${gridAnalysis.gridSize.cols} (${cells.length} cells)`);
      console.log(`📐 Total area: ${gridAnalysis.totalAreaKm2.toFixed(1)} km²`);
    }
  }

  printCompletionReport(cells, processingStats) {
    const totalTime = ((Date.now() - this.startTime) / 1000 / 60).toFixed(1);
    const stats = this.gridProcessor.getCellsByStatus();

    console.log('\n🎉 PROCESSING COMPLETED!');
    console.log('='.repeat(50));
    console.log(`📍 Area: ${this.config.get('area.name')}`);
    console.log(`⏱️  Total time: ${totalTime} minutes`);
    console.log(`🔲 Cells processed: ${stats.processed}/${stats.total}`);
    console.log(`📈 Success rate: ${((stats.processed / stats.total) * 100).toFixed(1)}%`);
    if (processingStats) {
      console.log(`📦 Data downloaded: ${processingStats.totalDataMB} MB`);
      console.log(`⚡ Speed: ${processingStats.cellsPerMinute} cells/min`);
    }
    console.log(`📁 Output: ${this.outputDir}`);
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  chunkArray(array, chunkSize) {
    const chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  }
}

// 🔹 Run if script is main
async function main() {
  const pipeline = new EnhancedPipeline();

  try {
    await pipeline.initialize();
    await pipeline.run();
    console.log('\n✅ Pipeline completed successfully!');
    process.exit(0);

  } catch (error) {
    console.error('\n💥 Pipeline failed:', error.message);
    process.exit(1);
  }
}

process.on('SIGINT', () => {
  console.log('\n👋 Pipeline interrupted by user');
  process.exit(0);
});

process.on('uncaughtException', (error) => {
  console.error('💥 Uncaught exception:', error.message);
  console.error('Stack trace:', error.stack);
  process.exit(1);
});

if (require.main === module) {
  main();
}
