
from datetime import datetime, timedelta

end = datetime.now()  # today
start = datetime.now()
# subtract 5 months approximately by subtracting 5*30 days
start = start - timedelta(days=5*30)

CONFIG_NAME_COORDS = {
    "name": "Shikher-7",
    "farmPolygon": [
        [
            [
                78.0037700240544,
                27.29097276715494
            ],
            [
                78.00440286134858,
                27.29097276715494
            ],
            [
                78.00440286134858,
                27.291403290038375
            ],
            [
                78.0037700240544,
                27.291403290038375
            ],
            [
                78.0037700240544,
                27.29097276715494
            ]
        ]
    ],
    "dateRange": {
        "start": start.strftime("%Y-%m-%d"),
        "end": end.strftime("%Y-%m-%d")
    },
    "cloudThreshold": 50,  # Higher threshold to ensure images exist
    "imageParams": {
        "scale": 10,        # 10m per pixel
        "maxPixels": 1e8,   # Higher limit to avoid truncation
        "dimensions": None, # Let GEE calculate optimal dimensions
        "region": None,     # Will be set from polygon

        # CRITICAL: Add explicit format options
        "format": "GEO_TIFF",
        "formatOptions": {
            "cloudOptimized": True,
            "noData": -9999
        }
    }
}
