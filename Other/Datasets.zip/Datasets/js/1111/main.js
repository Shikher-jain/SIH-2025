/**
 * Main Script - Test15 NDVI and Sensor Data Processing Pipeline
 * A specialized pipeline for processing NDVI data and sensor data with 20 bands (4 bands each for ECe, N, P, pH, OC)
 */

const ConfigManager = require('./modules/config');
const EarthEngineManager = require('./modules/earth-engine');
const { GridProcessor } = require('./modules/grid-processor');
const DataDownloader = require('./modules/data-downloader');
const MetadataManager = require('./modules/metadata-manager');
const ProgressTracker = require('./modules/progress-tracker');
const FileUtils = require('./modules/file-utils');
 
class SatelliteSensorPipeline {
  constructor() {
    this.config = null;
    this.earthEngine = null;
    this.gridProcessor = null;
    this.dataDownloader = null;
    this.metadataManager = null;
    this.progressTracker = null;
    this.outputDir = null;
    this.startTime = null;
  }

  /**
   * Initialize the pipeline
   */
  async initialize() {
    try {
      console.log('🚀 Test15 - Satellite & Sensor Data Processing Pipeline');
      console.log('='.repeat(60));
      
      // Load configuration
      this.config = new ConfigManager('./config.json');
      console.log(`📍 Area: ${this.config.get('area.name')}`);
      
      // Initialize Earth Engine
      this.earthEngine = new EarthEngineManager();
      await this.earthEngine.initialize();
      
      // Initialize modules
      this.gridProcessor = new GridProcessor(this.config, this.earthEngine);
      this.dataDownloader = new DataDownloader(this.config, this.earthEngine);
      this.metadataManager = new MetadataManager(this.config);
      this.fileUtils = new FileUtils(this.config);
      
      // Create output directory
      this.outputDir = this.config.createOutputStructure();
      console.log(`📁 Output: ${this.outputDir}`);
      
    } catch (error) {
      console.error('❌ Pipeline initialization failed:', error.message);
      throw error;
    }
  }

  /**
   * Main processing function
   */
  async run() {
    try {
      this.startTime = Date.now();
      
      console.log('🌍 Starting NDVI & Sensor Data Processing');
      console.log('='.repeat(60));
      
      // Generate grid for multiple areas
      const areaInfo = this.config.getAreaInfo();
      let allCells = [];
      
      if (areaInfo.type === 'geojson') {
        console.log(`🗺️  Processing ${areaInfo.geojson.features.length} GeoJSON polygons`);
        
        for (let i = 0; i < areaInfo.geojson.features.length; i++) {
          const feature = areaInfo.geojson.features[i];
          const polygon = feature.geometry.coordinates[0]; // Extract exterior ring
          
          console.log(`\n📍 Processing area ${i + 1}/${areaInfo.geojson.features.length}`);
          
          // Calculate area to check size limit
          const bounds = this.calculatePolygonBounds(polygon);
          const areaKm2 = this.calculatePolygonArea(bounds);
          
          console.log(`   📐 Area: ${areaKm2.toFixed(2)} km²`);
          
          if (areaInfo.maxAreaKm2 && areaKm2 > areaInfo.maxAreaKm2) {
            console.log(`   ⏭️  Skipping area ${i + 1} - too large (${areaKm2.toFixed(2)} km² > ${areaInfo.maxAreaKm2} km²)`);
            continue;
          }
          
          try {
            const areaCells = await this.gridProcessor.generateGrid(polygon);
            // Add area prefix to cell IDs to avoid conflicts
            areaCells.forEach(cell => {
              cell.id = `area${i + 1}_${cell.id}`;
              cell.areaIndex = i;
            });
            allCells = allCells.concat(areaCells);
          } catch (error) {
            console.error(`   ❌ Failed to process area ${i + 1}: ${error.message}`);
          }
        }
      } else {
        // Legacy single polygon processing
        allCells = await this.gridProcessor.generateGrid(areaInfo.polygon);
      }
      
      const gridAnalysis = this.gridProcessor.getGridAnalysis();
      const cells = allCells;
      
      // Initialize progress tracker
      this.progressTracker = new ProgressTracker(cells.length);
      
      this.printGridInfo(gridAnalysis, cells);
      this.printProcessingInfo();
      
      // Process cells in batches
      await this.processCellsBatched(cells);
      
      // Handle retries
      await this.handleRetries(cells);
      
      // Generate final summary
      const processingStats = this.progressTracker.getDetailedStats();
      await this.generateFinalSummary(cells, gridAnalysis, processingStats);
      
      this.printCompletionReport(cells, processingStats);
      
    } catch (error) {
      console.error('❌ Pipeline execution failed:', error.message);
      throw error;
    }
  }

  /**
   * Print processing configuration information
   */
  printProcessingInfo() {
    const ndviConfig = this.config.get('ndvi');
    const sensorConfig = this.config.get('sensor');
    const bandStackingConfig = this.config.get('output.bandStacking');
    const separateFiles = this.config.get('processing.separateFiles');
    
    console.log('\n📊 Processing Configuration:');
    console.log(`   🛰️  NDVI Satellite: ${ndviConfig.satellite}`);
    console.log(`   📅 Date Range: ${ndviConfig.dateRangeMonths} months`);
    console.log(`   ☁️  Cloud Threshold: ${ndviConfig.cloudThreshold}%`);
    console.log(`   🔍 NDVI Scale: ${ndviConfig.scale}m`);
    console.log(`   📊 Sensor Scale: ${sensorConfig.scale}m`);
    
    if (separateFiles) {
      console.log(`   📋 Mode: Separate Files (3 files per area)`);
      console.log(`   📊 Output Format: .npy (NDVI) + .tif (Sensor) + .json (Metadata)`);
      console.log(`   🖼️  Dimensions: 512x512 pixels at 10m resolution`);
      console.log(`   🌱 NDVI: 2D numpy array (512x512)`);
      console.log(`   📈 Sensor: 20-band .tif file (512x512)`);
    } else if (bandStackingConfig.enabled) {
      console.log(`   🔗 Band Stacking: Enabled`);
      console.log(`   📊 Output Format: NDVI as ${ndviConfig.format}, Sensor as .tif`);
      console.log(`   📦 Total Bands: ${bandStackingConfig.totalBands} (${bandStackingConfig.ndviBands} NDVI + ${bandStackingConfig.sensorBands} Sensor)`);
      console.log(`   🎯 Target Resolution: ${bandStackingConfig.targetResolution}m`);
    } else {
      console.log(`   🎯 NDVI: Numpy array at ${ndviConfig.scale}m`);
      console.log(`   🎯 Sensor: 20-band .tif upsampled to ${bandStackingConfig.targetResolution}m`);
    }
    
    // Print sensor configuration
    console.log('\n📈 Sensor Configuration:');
    Object.entries(sensorConfig.assets).forEach(([sensor, asset]) => {
      const bands = sensorConfig.bandConfiguration[sensor];
      console.log(`   ${sensor}: ${bands ? bands.bands.length : 4} bands - ${bands ? bands.description : 'Sensor data'}`);
    });
  }

  /**
   * Process cells in batches for better performance
   */
  async processCellsBatched(cells) {
    const processConfig = this.config.getProcessingConfig();
    const performanceConfig = this.config.getPerformanceConfig();
    
    if (!performanceConfig.enableBatching) {
      return await this.processCellsSequential(cells);
    }
    
    // Create batches from the provided cells array
    const batches = this.createCellBatches(cells, performanceConfig.batchSize);
    
    console.log(`\n🔄 Processing ${cells.length} cells in ${batches.length} batches`);
    console.log(`📊 Batch size: ${performanceConfig.batchSize} | Concurrent: ${processConfig.concurrentCells}`);
    
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      
      console.log(`\n${'='.repeat(60)}`);
      console.log(`🔄 BATCH ${i + 1}/${batches.length} - Processing ${batch.length} cells`);
      console.log(`${'='.repeat(60)}`);
      
      this.progressTracker.startBatch(i + 1, batch.length);
      
      // Process batch with concurrency control
      if (processConfig.concurrentCells > 1 && batch.length > 1) {
        await this.processBatchConcurrent(batch, processConfig.concurrentCells);
      } else {
        await this.processBatchSequential(batch);
      }
      
      this.progressTracker.completeBatch();
      this.progressTracker.printProgress();
      
      // Delay between batches
      if (i < batches.length - 1 && processConfig.delayBetweenBatches > 0) {
        console.log(`⏳ Batch delay: ${processConfig.delayBetweenBatches}ms`);
        await this.delay(processConfig.delayBetweenBatches);
      }
    }
  }

  /**
   * Create batches from cells array
   */
  createCellBatches(cells, batchSize) {
    const batches = [];
    for (let i = 0; i < cells.length; i += batchSize) {
      batches.push(cells.slice(i, i + batchSize));
    }
    return batches;
  }

  /**
   * Process cells sequentially (fallback when batching is disabled)
   */
  async processCellsSequential(cells) {
    console.log(`\n🔄 Processing ${cells.length} cells sequentially`);
    
    for (let i = 0; i < cells.length; i++) {
      const cell = cells[i];
      console.log(`\n${'='.repeat(60)}`);
      console.log(`🔄 CELL ${i + 1}/${cells.length}`);
      console.log(`${'='.repeat(60)}`);
      
      await this.processCell(cell);
      
      // Progress update
      if ((i + 1) % 5 === 0 || i === cells.length - 1) {
        const processed = cells.filter(cell => cell.isProcessed()).length;
        const percent = ((i + 1) / cells.length * 100).toFixed(1);
        console.log(`\n📈 Progress: ${i + 1}/${cells.length} (${percent}%) | Processed: ${processed}`);
      }
    }
  }

  /**
   * Process batch with concurrent cell processing
   */
  async processBatchConcurrent(batch, concurrency) {
    const chunks = this.chunkArray(batch, concurrency);
    
    for (const chunk of chunks) {
      const promises = chunk.map(cell => this.processCell(cell));
      await Promise.allSettled(promises);
      
      // Small delay between concurrent chunks
      if (chunk !== chunks[chunks.length - 1]) {
        await this.delay(1000);
      }
    }
  }

  /**
   * Process batch sequentially
   */
  async processBatchSequential(batch) {
    for (const cell of batch) {
      await this.processCell(cell);
    }
  }

  /**
   * Process individual cell
   */
  async processCell(cell) {
    const cellTracker = this.progressTracker.startCell(cell.id);
    const processConfig = this.config.getProcessingConfig();
    
    try {
      console.log(`\n🔲 Processing Cell ${cell.id}`);
      console.log(`   📍 Center: ${cell.getCenter().join(', ')} | Area: ${cell.areaKm2.toFixed(1)} km²`);
      
      // Create cell output directory
      cell.outputDir = this.fileUtils.createCellOutputDir(cell.id, this.outputDir);
      
      // Check for existing data
      if (processConfig.skipExisting) {
        const existing = this.fileUtils.checkExistingData(cell.outputDir);
        if (existing.ndvi && existing.sensor && existing.metadata) {
          console.log(`   ⏭️ Skipping - complete data exists`);
          this.progressTracker.skipCell(cell.id);
          return;
        }
      }
      
      let stackedResult = null;
      let ndviResult = null;
      let sensorResult = null;
      
      // Use separate downloads to generate 3 files: .npy (NDVI), .tif (sensor), metadata.json
      const separateFiles = this.config.get('processing.separateFiles');
      const bandStackingEnabled = this.config.get('processing.enableBandStacking') && !separateFiles;
      
      if (bandStackingEnabled && !separateFiles) {
        // Use band stacking - single 21-band .tif output (1 NDVI + 20 sensor)
        console.log(`   🔗 Using band stacking mode - single 21-band output`);
        
        try {
          this.progressTracker.startNDVIDownload(cellTracker);
          stackedResult = await this.dataDownloader.downloadStackedNDVISensorData(cell, cell.outputDir);
          this.progressTracker.completeNDVIDownload(cellTracker, true, stackedResult.fileSize);
          console.log(`   ✅ Stacked NDVI+Sensor data (21 bands): ${stackedResult.fileSize.toFixed(2)} MB`);
        } catch (error) {
          this.progressTracker.completeNDVIDownload(cellTracker, false);
          console.log(`   ❌ Stacked data failed: ${error.message}`);
        }
      } else {
        // Use separate downloads - NDVI .npy + Sensor .tif + metadata.json
        console.log(`   📋 Using separate file mode - NDVI .npy + Sensor .tif + metadata.json`);
        
        // Download NDVI data as 512x512 numpy array
        if (this.config.get('processing.downloadNDVI') && !this.fileUtils.checkExistingData(cell.outputDir).ndvi) {
          this.progressTracker.startNDVIDownload(cellTracker);
          try {
            ndviResult = await this.dataDownloader.downloadNDVIData(cell, cell.outputDir);
            this.progressTracker.completeNDVIDownload(cellTracker, true, ndviResult.fileSize);
            console.log(`   ✅ NDVI data (512x512 .npy): ${ndviResult.fileSize.toFixed(2)} MB`);
          } catch (error) {
            this.progressTracker.completeNDVIDownload(cellTracker, false);
            console.log(`   ❌ NDVI failed: ${error.message}`);
          }
        }
        
        // Small delay between downloads
        await this.delay(processConfig.delayBetweenCells);
        
        // Download sensor data as 512x512 .tif (20 bands)
        if (this.config.get('processing.downloadSensor') && !this.fileUtils.checkExistingData(cell.outputDir).sensor) {
          this.progressTracker.startSensorDownload(cellTracker);
          try {
            sensorResult = await this.dataDownloader.downloadSensorData(cell, cell.outputDir);
            this.progressTracker.completeSensorDownload(cellTracker, true, sensorResult.fileSize);
            console.log(`   ✅ Sensor data (512x512 .tif): ${sensorResult.fileSize.toFixed(2)} MB`);
          } catch (error) {
            this.progressTracker.completeSensorDownload(cellTracker, false);
            console.log(`   ❌ Sensor failed: ${error.message}`);
          }
        }
      }
      
      // Create metadata
      try {
        const metadataResult = this.metadataManager.createCellMetadata(
          cell, 
          bandStackingEnabled ? stackedResult : ndviResult, 
          bandStackingEnabled ? null : sensorResult, 
          cell.outputDir
        );
        cell.metadata = metadataResult.metadata;
      } catch (error) {
        console.log(`   ⚠️ Metadata creation failed: ${error.message}`);
      }
      
      // Mark cell as processed
      const processingTime = Date.now() - cellTracker.startTime;
      cell.markSuccess(
        bandStackingEnabled ? stackedResult : ndviResult, 
        bandStackingEnabled ? null : sensorResult, 
        processingTime
      );
      
      this.progressTracker.completeCell(cellTracker, true);
      console.log(`   ✅ Cell ${cell.id} completed`);
      
    } catch (error) {
      cell.markError(error.message);
      this.progressTracker.completeCell(cellTracker, false, error.message);
      console.error(`   ❌ Cell ${cell.id} failed: ${error.message}`);
    }
  }

  /**
   * Handle failed cell retries
   */
  async handleRetries(cells) {
    const maxRetries = this.config.get('processing.retryAttempts') || 3;
    const retryableCells = cells.filter(cell => 
      cell.hasError() && !cell.isProcessed() && cell.canRetry(maxRetries)
    );
    
    if (retryableCells.length === 0) return;
    
    console.log(`\n🔄 Retrying ${retryableCells.length} failed cells`);
    console.log('='.repeat(60));
    
    for (let i = 0; i < retryableCells.length; i++) {
      const cell = retryableCells[i];
      console.log(`\n🔄 RETRY ${i + 1}/${retryableCells.length}: Cell ${cell.id}`);
      
      cell.reset();
      await this.processCell(cell);
      
      const processConfig = this.config.getProcessingConfig();
      if (processConfig.retryDelayMs > 0) {
        await this.delay(processConfig.retryDelayMs);
      }
    }
  }

  /**
   * Generate final processing summary
   */
  async generateFinalSummary(cells, gridAnalysis, processingStats) {
    try {
      console.log('\n📊 Generating final summary...');
      
      const summaryResult = this.metadataManager.createProcessingSummary(
        cells, gridAnalysis, processingStats, this.outputDir
      );
      
      // Create file manifest
      const manifest = this.fileUtils.createFileManifest(
        this.outputDir, 
        `${this.outputDir}/file_manifest.json`
      );
      
      console.log(`📋 Files manifest: ${manifest.summary.totalFiles} files, ${manifest.summary.totalSizeMB} MB`);
      
    } catch (error) {
      console.error(`❌ Failed to generate summary: ${error.message}`);
    }
  }

  /**
   * Print grid information
   */
  printGridInfo(gridAnalysis, cells) {
    if (gridAnalysis.isSingleCell) {
      console.log(`🔲 Single cell mode (${gridAnalysis.totalAreaKm2.toFixed(1)} km²)`);
    } else {
      console.log(`📊 Grid: ${gridAnalysis.gridSize.rows}×${gridAnalysis.gridSize.cols} (${cells.length} cells)`);
      console.log(`📐 Total area: ${gridAnalysis.totalAreaKm2.toFixed(1)} km²`);
    }
  }

  /**
   * Print completion report
   */
  printCompletionReport(cells, processingStats) {
    const totalTime = ((Date.now() - this.startTime) / 1000 / 60).toFixed(1);
    
    // Calculate statistics from cells array
    const processed = cells.filter(cell => cell.isProcessed()).length;
    const failed = cells.filter(cell => cell.hasError()).length;
    const total = cells.length;
    
    console.log('\n🎉 NDVI & SENSOR PROCESSING COMPLETED!');
    console.log('='.repeat(50));
    console.log(`📍 Area: ${this.config.get('area.name')}`);
    console.log(`⏱️  Total time: ${totalTime} minutes`);
    console.log(`🔲 Cells processed: ${processed}/${total}`);
    console.log(`📈 Success rate: ${((processed / total) * 100).toFixed(1)}%`);
    
    if (processingStats) {
      console.log(`📦 Data downloaded: ${processingStats.totalDataMB} MB`);
      console.log(`⚡ Speed: ${processingStats.cellsPerMinute} cells/min`);
    }
    
    // Show breakdown by area if multiple areas
    const areaInfo = this.config.getAreaInfo();
    if (areaInfo.type === 'geojson' && areaInfo.geojson.features.length > 1) {
      console.log('\n🗺️ Areas Breakdown:');
      for (let i = 0; i < areaInfo.geojson.features.length; i++) {
        const areaCells = cells.filter(cell => cell.id.startsWith(`area${i + 1}_`));
        const areaProcessed = areaCells.filter(cell => cell.isProcessed()).length;
        console.log(`   Area ${i + 1}: ${areaProcessed}/${areaCells.length} cells processed`);
      }
    }
    
    console.log(`📁 Output: ${this.outputDir}`);
  }

  /**
   * Utility functions
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  chunkArray(array, chunkSize) {
    const chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  }

  /**
   * Calculate polygon bounds
   */
  calculatePolygonBounds(polygon) {
    const lons = polygon.map(coord => coord[0]);
    const lats = polygon.map(coord => coord[1]);
    
    return {
      minLon: Math.min(...lons),
      maxLon: Math.max(...lons),
      minLat: Math.min(...lats),
      maxLat: Math.max(...lats)
    };
  }

  /**
   * Calculate approximate polygon area using bounding box
   */
  calculatePolygonArea(bounds) {
    const widthKm = this.haversineDistance(
      bounds.minLat, bounds.minLon, 
      bounds.minLat, bounds.maxLon
    );
    
    const heightKm = this.haversineDistance(
      bounds.minLat, bounds.minLon, 
      bounds.maxLat, bounds.minLon
    );
    
    return widthKm * heightKm;
  }

  /**
   * Calculate distance between two coordinates using Haversine formula
   */
  haversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
}

// Main execution
async function main() {
  const pipeline = new SatelliteSensorPipeline();
  
  try {
    await pipeline.initialize();
    await pipeline.run();
    
    console.log('\n✅ Satellite & Sensor Pipeline completed successfully!');
    process.exit(0);
    
  } catch (error) {
    console.error('\n💥 Pipeline failed:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\n👋 Pipeline interrupted by user');
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('💥 Uncaught exception:', error.message);
  console.error('Stack trace:', error.stack);
  process.exit(1);
});

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = SatelliteSensorPipeline;