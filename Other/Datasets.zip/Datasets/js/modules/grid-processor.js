/**
 * Grid Processor Module for Test15
 * Handles grid generation, optimization, and cell management for NDVI & Sensor processing
 */

class GridCell {
  constructor(id, polygon, bounds, areaKm2) {
    this.id = id;
    this.polygon = polygon;
    this.bounds = bounds;
    this.areaKm2 = areaKm2;
    this.processed = false;
    this.ndviResult = null;
    this.sensorResult = null;
    this.error = null;
    this.retryCount = 0;
    this.outputDir = null;
    this.processingTime = null;
    this.metadata = null;
  }

  getBounds() {
    return {
      minLon: this.bounds.minLon,
      maxLon: this.bounds.maxLon,
      minLat: this.bounds.minLat,
      maxLat: this.bounds.maxLat,
      centerLon: (this.bounds.minLon + this.bounds.maxLon) / 2,
      centerLat: (this.bounds.minLat + this.bounds.maxLat) / 2
    };
  }

  getCenter() {
    const bounds = this.getBounds();
    return [bounds.centerLon, bounds.centerLat];
  }

  isProcessed() {
    return this.processed;
  }

  hasError() {
    return this.error !== null;
  }

  canRetry(maxRetries) {
    return this.retryCount < maxRetries;
  }

  markSuccess(ndviResult, sensorResult, processingTime) {
    this.processed = true;
    this.ndviResult = ndviResult;
    this.sensorResult = sensorResult;
    this.processingTime = processingTime;
    this.error = null;
  }

  markError(error) {
    this.error = error;
    this.retryCount++;
  }

  reset() {
    this.error = null;
    this.processed = false;
  }
}

class GridProcessor {
  constructor(config, earthEngine) {
    this.config = config;
    this.ee = earthEngine;
    this.cells = [];
    this.gridAnalysis = null;
  }

  /**
   * Generate grid for the given polygon
   */
  async generateGrid(polygon) {
    try {
      console.log('🔍 Generating grid for NDVI & Sensor processing...');
      
      // Calculate optimal grid
      this.gridAnalysis = await this.calculateOptimalGrid(polygon);
      
      // Generate cells
      this.cells = await this.generateCells(polygon, this.gridAnalysis);
      
      console.log(`✅ Grid generated: ${this.cells.length} cells`);
      
      return this.cells;
      
    } catch (error) {
      console.error('❌ Grid generation failed:', error.message);
      throw error;
    }
  }

  /**
   * Calculate optimal grid size based on area
   */
  async calculateOptimalGrid(polygon) {
    console.log('🔍 Calculating optimal grid size...');
    
    try {
      // Calculate area using simple bounding box method (fallback for EE unavailable)
      const bounds = this.calculateBounds(polygon);
      const dimensions = this.calculateDimensions(bounds);
      const totalAreaKm2 = dimensions.widthKm * dimensions.heightKm;
      
      console.log(`📐 Estimated area: ${totalAreaKm2.toFixed(2)} km²`);
      console.log(`📏 Bounding box: ${dimensions.widthKm.toFixed(2)} km × ${dimensions.heightKm.toFixed(2)} km`);
      
      // For very small areas, use single cell
      const maxCellArea = this.config.get('grid.maxCellAreaKm2');
      if (totalAreaKm2 <= maxCellArea) {
        console.log(`🎯 Small area detected - using single cell (${totalAreaKm2.toFixed(2)} km² ≤ ${maxCellArea} km²)`);
        return {
          gridSize: { rows: 1, cols: 1 },
          totalAreaKm2: totalAreaKm2,
          cellAreaKm2: totalAreaKm2,
          cellDimensions: { widthKm: dimensions.widthKm, heightKm: dimensions.heightKm },
          isSingleCell: true,
          bounds: bounds,
          areaDimensions: dimensions
        };
      }
      
      // Calculate optimal grid dimensions
      const gridSize = this.calculateGridDimensions(totalAreaKm2, dimensions);
      
      // Calculate actual cell properties
      const actualCellAreaKm2 = totalAreaKm2 / (gridSize.rows * gridSize.cols);
      const cellWidthKm = dimensions.widthKm / gridSize.cols;
      const cellHeightKm = dimensions.heightKm / gridSize.rows;
      
      console.log(`✅ Optimal grid: ${gridSize.rows} × ${gridSize.cols} = ${gridSize.rows * gridSize.cols} cells`);
      console.log(`📐 Average cell area: ${actualCellAreaKm2.toFixed(2)} km²`);
      console.log(`📏 Cell dimensions: ${cellWidthKm.toFixed(2)} km × ${cellHeightKm.toFixed(2)} km`);
      
      // Validate against constraints
      this.validateGridConstraints(actualCellAreaKm2);
      
      return {
        gridSize: gridSize,
        totalAreaKm2: totalAreaKm2,
        cellAreaKm2: actualCellAreaKm2,
        cellDimensions: { widthKm: cellWidthKm, heightKm: cellHeightKm },
        isSingleCell: false,
        bounds: bounds,
        areaDimensions: dimensions
      };
      
    } catch (error) {
      console.error('❌ Grid calculation failed:', error.message);
      throw error;
    }
  }

  /**
   * Calculate bounding box of polygon
   */
  calculateBounds(polygon) {
    const lons = polygon.map(coord => coord[0]);
    const lats = polygon.map(coord => coord[1]);
    
    return {
      minLon: Math.min(...lons),
      maxLon: Math.max(...lons),
      minLat: Math.min(...lats),
      maxLat: Math.max(...lats)
    };
  }

  /**
   * Calculate dimensions using Haversine formula
   */
  calculateDimensions(bounds) {
    const widthKm = this.haversineDistance(
      bounds.minLat, bounds.minLon, 
      bounds.minLat, bounds.maxLon
    );
    
    const heightKm = this.haversineDistance(
      bounds.minLat, bounds.minLon, 
      bounds.maxLat, bounds.minLon
    );
    
    return { widthKm, heightKm };
  }

  /**
   * Calculate distance between two coordinates using Haversine formula
   */
  haversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  /**
   * Calculate grid dimensions based on area and preferences
   */
  calculateGridDimensions(totalAreaKm2, dimensions) {
    const gridConfig = this.config.get('grid');
    const targetCellArea = gridConfig.maxCellAreaKm2;
    const idealCellCount = Math.ceil(totalAreaKm2 / targetCellArea);
    
    console.log(`🎯 Target cell area: ${targetCellArea.toFixed(0)} km² per cell`);
    console.log(`🔢 Ideal cell count: ${idealCellCount}`);
    
    let optimalGrid;
    
    if (gridConfig.preferSquareCells) {
      optimalGrid = this.calculateSquareGrid(idealCellCount, dimensions);
    } else {
      optimalGrid = this.calculateProportionalGrid(targetCellArea, dimensions);
    }
    
    // Apply constraints
    const minGridSize = gridConfig.minGridSize || 1;
    const maxGridSize = gridConfig.maxGridSize || 100;
    
    optimalGrid.rows = Math.max(minGridSize, Math.min(maxGridSize, optimalGrid.rows));
    optimalGrid.cols = Math.max(minGridSize, Math.min(maxGridSize, optimalGrid.cols));
    
    return optimalGrid;
  }

  /**
   * Calculate square grid dimensions
   */
  calculateSquareGrid(idealCellCount, dimensions) {
    const aspectRatio = dimensions.widthKm / dimensions.heightKm;
    let gridSide = Math.sqrt(idealCellCount);
    
    if (aspectRatio > 1.5) {
      // Wide rectangle - more columns
      const cols = Math.ceil(gridSide * Math.sqrt(aspectRatio));
      const rows = Math.ceil(idealCellCount / cols);
      return { rows, cols };
    } else if (aspectRatio < 0.67) {
      // Tall rectangle - more rows
      const rows = Math.ceil(gridSide * Math.sqrt(1/aspectRatio));
      const cols = Math.ceil(idealCellCount / rows);
      return { rows, cols };
    } else {
      // Square-ish - equal distribution
      const side = Math.ceil(gridSide);
      return { rows: side, cols: side };
    }
  }

  /**
   * Calculate proportional grid dimensions
   */
  calculateProportionalGrid(targetCellArea, dimensions) {
    const cellWidthKm = Math.sqrt(targetCellArea);
    const cellHeightKm = Math.sqrt(targetCellArea);
    
    const cols = Math.ceil(dimensions.widthKm / cellWidthKm);
    const rows = Math.ceil(dimensions.heightKm / cellHeightKm);
    
    return { rows, cols };
  }

  /**
   * Validate grid constraints
   */
  validateGridConstraints(cellAreaKm2) {
    const gridConfig = this.config.get('grid');
    
    if (cellAreaKm2 > gridConfig.maxCellAreaKm2) {
      console.warn(`⚠️ Cell area (${cellAreaKm2.toFixed(2)} km²) exceeds maximum (${gridConfig.maxCellAreaKm2} km²)`);
    }
    
    if (cellAreaKm2 < gridConfig.minCellAreaKm2) {
      console.warn(`⚠️ Cell area (${cellAreaKm2.toFixed(2)} km²) below minimum (${gridConfig.minCellAreaKm2} km²)`);
    }
  }

  /**
   * Generate individual cells based on grid analysis
   */
  async generateCells(polygon, gridAnalysis) {
    const cells = [];
    const { gridSize, bounds } = gridAnalysis;
    
    if (gridAnalysis.isSingleCell) {
      // Single cell mode
      const cell = new GridCell(
        'cell_01',
        polygon,
        bounds,
        gridAnalysis.totalAreaKm2
      );
      cells.push(cell);
    } else {
      // Multi-cell grid
      const cellWidthDeg = (bounds.maxLon - bounds.minLon) / gridSize.cols;
      const cellHeightDeg = (bounds.maxLat - bounds.minLat) / gridSize.rows;
      
      for (let row = 0; row < gridSize.rows; row++) {
        for (let col = 0; col < gridSize.cols; col++) {
          const cellId = `cell_${String(row + 1).padStart(2, '0')}_${String(col + 1).padStart(2, '0')}`;
          
          const cellBounds = {
            minLon: bounds.minLon + (col * cellWidthDeg),
            maxLon: bounds.minLon + ((col + 1) * cellWidthDeg),
            minLat: bounds.minLat + (row * cellHeightDeg),
            maxLat: bounds.minLat + ((row + 1) * cellHeightDeg)
          };
          
          const cellPolygon = [
            [cellBounds.minLon, cellBounds.minLat],
            [cellBounds.maxLon, cellBounds.minLat],
            [cellBounds.maxLon, cellBounds.maxLat],
            [cellBounds.minLon, cellBounds.maxLat],
            [cellBounds.minLon, cellBounds.minLat]
          ];
          
          const cellAreaKm2 = gridAnalysis.cellAreaKm2;
          
          const cell = new GridCell(cellId, cellPolygon, cellBounds, cellAreaKm2);
          cells.push(cell);
        }
      }
    }
    
    return cells;
  }

  /**
   * Create batches for processing
   */
  createBatches(batchSize) {
    const batches = [];
    for (let i = 0; i < this.cells.length; i += batchSize) {
      batches.push(this.cells.slice(i, i + batchSize));
    }
    return batches;
  }

  /**
   * Get cells by processing status
   */
  getCellsByStatus() {
    const processed = this.cells.filter(cell => cell.isProcessed()).length;
    const failed = this.cells.filter(cell => cell.hasError()).length;
    const pending = this.cells.length - processed;
    
    return {
      total: this.cells.length,
      processed: processed,
      failed: failed,
      pending: pending
    };
  }

  /**
   * Get cells that can be retried
   */
  getRetryableCells() {
    const maxRetries = this.config.get('processing.retryAttempts') || 3;
    return this.cells.filter(cell => 
      cell.hasError() && !cell.isProcessed() && cell.canRetry(maxRetries)
    );
  }

  /**
   * Get grid analysis
   */
  getGridAnalysis() {
    return this.gridAnalysis;
  }

  /**
   * Get all cells
   */
  getCells() {
    return this.cells;
  }

  /**
   * Get cell by ID
   */
  getCellById(id) {
    return this.cells.find(cell => cell.id === id);
  }

  /**
   * Reset all cells for reprocessing
   */
  resetAllCells() {
    this.cells.forEach(cell => cell.reset());
  }

  /**
   * Get processing statistics
   */
  getProcessingStats() {
    const stats = this.getCellsByStatus();
    const totalProcessingTime = this.cells
      .filter(cell => cell.processingTime)
      .reduce((sum, cell) => sum + cell.processingTime, 0);
    
    const avgProcessingTime = stats.processed > 0 ? totalProcessingTime / stats.processed : 0;
    
    return {
      ...stats,
      totalProcessingTime: totalProcessingTime,
      avgProcessingTime: avgProcessingTime,
      successRate: stats.total > 0 ? (stats.processed / stats.total) * 100 : 0
    };
  }
}

module.exports = { GridProcessor, GridCell };