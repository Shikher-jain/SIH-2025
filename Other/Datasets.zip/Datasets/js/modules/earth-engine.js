/**
 * Earth Engine Manager Module
 * Handles Google Earth Engine authentication and data access for Test15
 */

const ee = require('@google/earthengine');
const fs = require('fs');
const path = require('path');

class EarthEngineManager {
  constructor() {
    this.initialized = false;
    this.serviceAccountPath = null;
  }

  /**
   * Initialize Google Earth Engine
   */
  async initialize(serviceAccountPath = './earth-engine-service-account.json') {
    try {
      console.log('🔐 Initializing Google Earth Engine...');
      
      this.serviceAccountPath = path.resolve(serviceAccountPath);
      
      // Check if service account file exists
      if (!fs.existsSync(this.serviceAccountPath)) {
        throw new Error(`Service account file not found: ${this.serviceAccountPath}`);
      }

      // Load service account credentials
      const serviceAccount = JSON.parse(fs.readFileSync(this.serviceAccountPath, 'utf8'));
      
      // Initialize Earth Engine with updated approach
      return new Promise((resolve, reject) => {
        // Set authentication first
        ee.data.authenticateViaPrivateKey(
          serviceAccount,
          () => {
            // Then initialize
            ee.initialize(
              null,
              null,
              (error) => {
                if (error) {
                  console.error('❌ Earth Engine initialization failed:', error.message);
                  reject(error);
                } else {
                  console.log('✅ Google Earth Engine initialized successfully');
                  this.initialized = true;
                  resolve();
                }
              },
              null,
              serviceAccount.project_id
            );
          },
          (error) => {
            console.error('❌ Earth Engine authentication failed:', error.message);
            reject(error);
          }
        );
      });
      
    } catch (error) {
      console.error('❌ Earth Engine initialization error:', error.message);
      throw error;
    }
  }

  /**
   * Check if Earth Engine is initialized
   */
  isInitialized() {
    return this.initialized;
  }

  /**
   * Create geometry from polygon coordinates
   */
  createGeometry(polygon) {
    try {
      return ee.Geometry.Polygon(polygon);
    } catch (error) {
      throw new Error(`Failed to create geometry: ${error.message}`);
    }
  }

  /**
   * Get NDVI collection based on satellite type
   */
  getNDVICollection(region, startDate, endDate, cloudThreshold, satellite = 'COPERNICUS/S2_SR') {
    try {
      let collection;
      
      switch (satellite) {
        case 'LANDSAT/LC08/C01/T1_SR':
        case 'LANDSAT_8':
          collection = ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
            .filterBounds(region)
            .filterDate(startDate, endDate)
            .filter(ee.Filter.lt('CLOUD_COVER', cloudThreshold));
          break;
          
        case 'LANDSAT/LC09/C02/T1_L2':
        case 'LANDSAT_9':
          collection = ee.ImageCollection('LANDSAT/LC09/C02/T1_L2')
            .filterBounds(region)
            .filterDate(startDate, endDate)
            .filter(ee.Filter.lt('CLOUD_COVER', cloudThreshold));
          break;
          
        case 'COPERNICUS/S2_SR':
        case 'SENTINEL_2':
        default:
          collection = ee.ImageCollection('COPERNICUS/S2_SR')
            .filterBounds(region)
            .filterDate(startDate, endDate)
            .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloudThreshold));
          break;
      }
      
      return collection;
      
    } catch (error) {
      throw new Error(`Failed to get NDVI collection: ${error.message}`);
    }
  }

  /**
   * Calculate NDVI from satellite collection
   */
  calculateNDVI(collection, satellite = 'COPERNICUS/S2_SR') {
    try {
      let ndviFunction;
      
      switch (satellite) {
        case 'LANDSAT/LC08/C02/T1_L2':
        case 'LANDSAT_8':
          ndviFunction = (image) => {
            const ndvi = image.normalizedDifference(['SR_B5', 'SR_B4']).rename('NDVI');
            return image.addBands(ndvi);
          };
          break;
          
        case 'LANDSAT/LC09/C02/T1_L2':
        case 'LANDSAT_9':
          ndviFunction = (image) => {
            const ndvi = image.normalizedDifference(['SR_B5', 'SR_B4']).rename('NDVI');
            return image.addBands(ndvi);
          };
          break;
          
        case 'COPERNICUS/S2_SR':
        case 'SENTINEL_2':
        default:
          ndviFunction = (image) => {
            const ndvi = image.normalizedDifference(['B8', 'B4']).rename('NDVI');
            return image.addBands(ndvi);
          };
          break;
      }
      
      return collection.map(ndviFunction);
      
    } catch (error) {
      throw new Error(`Failed to calculate NDVI: ${error.message}`);
    }
  }

  /**
   * Get NDVI collection with advanced date filtering
   */
  getNDVICollectionAdvanced(region, dateRange, cloudThreshold, satellite = 'COPERNICUS/S2_SR') {
    try {
      console.log(`   📡 Getting ${satellite} collection for NDVI...`);
      
      let collection = this.getNDVICollection(region, dateRange.start, dateRange.end, cloudThreshold, satellite);
      
      // Apply additional filtering based on date range mode
      if (dateRange.mode === 'specificMonthYear' && dateRange.periods) {
        // Filter for specific month/year combinations
        const filters = dateRange.periods.map(period => {
          const startDate = new Date(period.year, period.month - 1, 1);
          const endDate = new Date(period.year, period.month, 0);
          return ee.Filter.date(startDate.toISOString().split('T')[0], endDate.toISOString().split('T')[0]);
        });
        
        if (filters.length > 0) {
          collection = collection.filter(ee.Filter.or(...filters));
        }
      }
      
      // Calculate NDVI for the collection
      collection = this.calculateNDVI(collection, satellite);
      
      return collection;
      
    } catch (error) {
      console.error(`Error in getNDVICollectionAdvanced: ${error.message}`);
      throw new Error(`Failed to get advanced NDVI collection: ${error.message}`);
    }
  }

  /**
   * Get sensor image from asset ID
   */
  getSensorImage(assetId) {
    try {
      return ee.Image(assetId);
    } catch (error) {
      throw new Error(`Failed to load sensor image ${assetId}: ${error.message}`);
    }
  }

  /**
   * Get collection size
   */
  async getCollectionSize(collection) {
    try {
      return new Promise((resolve, reject) => {
        collection.size().evaluate((result, error) => {
          if (error) {
            console.error('Collection size evaluation error:', error);
            reject(new Error(`Failed to get collection size: ${error.message || error}`));
          } else {
            resolve(result || 0);
          }
        });
      });
    } catch (error) {
      console.error('Collection size wrapper error:', error);
      throw new Error(`Collection size evaluation failed: ${error.message}`);
    }
  }

  /**
   * Get image information
   */
  async getImageInfo(image) {
    try {
      return new Promise((resolve, reject) => {
        image.getInfo((result, error) => {
          if (error) {
            reject(new Error(`Failed to get image info: ${error.message}`));
          } else {
            resolve(result);
          }
        });
      });
    } catch (error) {
      throw new Error(`Image info evaluation failed: ${error.message}`);
    }
  }

  /**
   * Get image date
   */
  async getImageDate(image) {
    try {
      return new Promise((resolve, reject) => {
        image.date().format('YYYY-MM-dd').evaluate((result, error) => {
          if (error) {
            reject(new Error(`Failed to get image date: ${error.message}`));
          } else {
            resolve(result);
          }
        });
      });
    } catch (error) {
      throw new Error(`Image date evaluation failed: ${error.message}`);
    }
  }

  /**
   * Get image property
   */
  async getImageProperty(image, property) {
    try {
      return new Promise((resolve, reject) => {
        image.get(property).evaluate((result, error) => {
          if (error) {
            reject(new Error(`Failed to get image property ${property}: ${error.message}`));
          } else {
            resolve(result);
          }
        });
      });
    } catch (error) {
      throw new Error(`Image property evaluation failed: ${error.message}`);
    }
  }

  /**
   * Get download URL for image
   */
  async getDownloadUrl(image, params) {
    try {
      return new Promise((resolve, reject) => {
        image.getDownloadURL(params, (url, error) => {
          if (error) {
            reject(new Error(`Failed to get download URL: ${error.message}`));
          } else {
            resolve(url);
          }
        });
      });
    } catch (error) {
      throw new Error(`Download URL generation failed: ${error.message}`);
    }
  }

  /**
   * Create NDVI numpy array export (for numpy array output)
   */
  async exportNDVIArrayToNumpy(ndviImage, region, scale = 100) {
    try {
      const params = {
        region: region,
        scale: scale,
        maxPixels: 1e10,
        format: 'NPY'
      };
      
      return await this.getDownloadUrl(ndviImage.select('NDVI'), params);
      
    } catch (error) {
      throw new Error(`Failed to export NDVI to numpy: ${error.message}`);
    }
  }

  /**
   * Create NDVI median composite from collection
   */
  createNDVIMedianComposite(ndviCollection, region) {
    try {
      const medianComposite = ndviCollection.select('NDVI').median().clip(region);
      return medianComposite;
    } catch (error) {
      throw new Error(`Failed to create NDVI median composite: ${error.message}`);
    }
  }

  /**
   * Create NDVI time series statistics
   */
  createNDVITimeSeriesStats(ndviCollection, region) {
    try {
      const mean = ndviCollection.select('NDVI').mean().rename('NDVI_mean');
      const median = ndviCollection.select('NDVI').median().rename('NDVI_median');
      const stdDev = ndviCollection.select('NDVI').reduce(ee.Reducer.stdDev()).rename('NDVI_stdDev');
      const max = ndviCollection.select('NDVI').max().rename('NDVI_max');
      const min = ndviCollection.select('NDVI').min().rename('NDVI_min');
      
      const stats = ee.Image.cat([mean, median, stdDev, max, min]).clip(region);
      return stats;
    } catch (error) {
      throw new Error(`Failed to create NDVI time series stats: ${error.message}`);
    }
  }

  /**
   * Validate sensor asset accessibility
   */
  async validateSensorAsset(assetId) {
    try {
      const image = ee.Image(assetId);
      const info = await this.getImageInfo(image);
      return {
        valid: true,
        bands: info.bands ? info.bands.length : 0,
        info: info
      };
    } catch (error) {
      return {
        valid: false,
        error: error.message
      };
    }
  }

  /**
   * Get Earth Engine API version info
   */
  getAPIInfo() {
    return {
      initialized: this.initialized,
      serviceAccountPath: this.serviceAccountPath,
      version: '1.6.6' // @google/earthengine version
    };
  }
}

module.exports = EarthEngineManager;