/**
 * NDVI Processor Module for Test15
 * Specialized processing for NDVI calculations and analysis
 */

const ee = require('@google/earthengine');
const path = require('path');
const fs = require('fs');

class NDVIProcessor {
  constructor(config, earthEngine) {
    this.config = config;
    this.ee = earthEngine;
    this.ndviConfig = config.get('ndvi');
  }

  /**
   * Process NDVI data for a specific cell and time period
   */
  async processNDVIForCell(cell, dateRange) {
    try {
      console.log(`   🌱 Processing NDVI for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      
      // Get NDVI collection
      const ndviCollection = await this.getNDVICollection(region, dateRange);
      
      // Calculate various NDVI statistics
      const ndviStats = await this.calculateNDVIStatistics(ndviCollection, region);
      
      // Create temporal analysis
      const temporalAnalysis = await this.createTemporalAnalysis(ndviCollection, region);
      
      console.log(`   ✅ NDVI processing completed for cell ${cell.id}`);
      
      return {
        success: true,
        statistics: ndviStats,
        temporal: temporalAnalysis,
        imageCount: await this.ee.getCollectionSize(ndviCollection)
      };
      
    } catch (error) {
      console.error(`   ❌ NDVI processing failed for cell ${cell.id}: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get NDVI collection for specified region and date range
   */
  async getNDVICollection(region, dateRange) {
    try {
      let collection = this.ee.getNDVICollectionAdvanced(
        region,
        dateRange,
        this.ndviConfig.cloudThreshold,
        this.ndviConfig.satellite
      );
      
      // Apply quality filtering
      collection = this.applyQualityFilter(collection);
      
      return collection;
      
    } catch (error) {
      throw new Error(`Failed to get NDVI collection: ${error.message}`);
    }
  }

  /**
   * Apply quality filtering to NDVI collection
   */
  applyQualityFilter(collection) {
    const satellite = this.ndviConfig.satellite;
    
    switch (satellite) {
      case 'LANDSAT_8':
        // Filter for clear pixels using pixel_qa band
        return collection.map((image) => {
          const qa = image.select('pixel_qa');
          const clear = qa.bitwiseAnd(64).eq(0) // Clear
            .and(qa.bitwiseAnd(32).eq(0)) // Water
            .and(qa.bitwiseAnd(16).eq(0)) // Cloud shadow
            .and(qa.bitwiseAnd(8).eq(0)) // Snow
            .and(qa.bitwiseAnd(4).eq(0)); // Cloud
          
          return image.updateMask(clear);
        });
        
      case 'LANDSAT_9':
        // Similar quality filtering for Landsat 9
        return collection.map((image) => {
          const qa = image.select('QA_PIXEL');
          const clear = qa.bitwiseAnd(1).eq(0) // Clear
            .and(qa.bitwiseAnd(8).eq(0)) // Cloud shadow
            .and(qa.bitwiseAnd(16).eq(0)) // Snow
            .and(qa.bitwiseAnd(32).eq(0)); // Cloud
          
          return image.updateMask(clear);
        });
        
      case 'SENTINEL_2':
        // Use SCL (Scene Classification Layer) for quality filtering
        return collection.map((image) => {
          const scl = image.select('SCL');
          const clear = scl.eq(4) // Vegetation
            .or(scl.eq(5)) // Not vegetated
            .or(scl.eq(6)) // Water
            .or(scl.eq(11)); // Snow
          
          return image.updateMask(clear);
        });
        
      default:
        return collection;
    }
  }

  /**
   * Calculate comprehensive NDVI statistics
   */
  async calculateNDVIStatistics(ndviCollection, region) {
    try {
      const ndviImages = ndviCollection.select('NDVI');
      
      // Basic statistics
      const mean = ndviImages.mean().rename('NDVI_mean');
      const median = ndviImages.median().rename('NDVI_median');
      const stdDev = ndviImages.reduce(ee.Reducer.stdDev()).rename('NDVI_stdDev');
      const max = ndviImages.max().rename('NDVI_max');
      const min = ndviImages.min().rename('NDVI_min');
      const count = ndviImages.count().rename('NDVI_count');
      
      // Advanced statistics
      const percentile25 = ndviImages.reduce(ee.Reducer.percentile([25])).rename('NDVI_p25');
      const percentile75 = ndviImages.reduce(ee.Reducer.percentile([75])).rename('NDVI_p75');
      const percentile95 = ndviImages.reduce(ee.Reducer.percentile([95])).rename('NDVI_p95');
      
      // Combine all statistics
      const allStats = ee.Image.cat([
        mean, median, stdDev, max, min, count,
        percentile25, percentile75, percentile95
      ]).clip(region);
      
      // Get regional statistics
      const regionalStats = await this.getRegionalStatistics(allStats, region);
      
      return {
        image: allStats,
        regional: regionalStats,
        bands: ['mean', 'median', 'stdDev', 'max', 'min', 'count', 'p25', 'p75', 'p95']
      };
      
    } catch (error) {
      throw new Error(`Failed to calculate NDVI statistics: ${error.message}`);
    }
  }

  /**
   * Create temporal analysis of NDVI data
   */
  async createTemporalAnalysis(ndviCollection, region) {
    try {
      // Create time series by month
      const months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
      const monthlyNDVI = {};
      
      for (const month of months) {
        const monthlyCollection = ndviCollection.filter(ee.Filter.calendarRange(month, month, 'month'));
        const monthlySize = await this.ee.getCollectionSize(monthlyCollection);
        
        if (monthlySize > 0) {
          const monthlyMedian = monthlyCollection.select('NDVI').median();
          const monthlyStats = await this.getRegionalStatistics(monthlyMedian, region);
          
          monthlyNDVI[month] = {
            imageCount: monthlySize,
            statistics: monthlyStats
          };
        }
      }
      
      // Create seasonal analysis
      const seasons = {
        spring: [3, 4, 5],
        summer: [6, 7, 8],
        autumn: [9, 10, 11],
        winter: [12, 1, 2]
      };
      
      const seasonalNDVI = {};
      for (const [seasonName, seasonMonths] of Object.entries(seasons)) {
        const seasonalCollection = ndviCollection.filter(
          ee.Filter.calendarRange(seasonMonths[0], seasonMonths[2], 'month')
        );
        const seasonalSize = await this.ee.getCollectionSize(seasonalCollection);
        
        if (seasonalSize > 0) {
          const seasonalMedian = seasonalCollection.select('NDVI').median();
          const seasonalStats = await this.getRegionalStatistics(seasonalMedian, region);
          
          seasonalNDVI[seasonName] = {
            imageCount: seasonalSize,
            statistics: seasonalStats
          };
        }
      }
      
      // Calculate trend if enough data
      const trend = await this.calculateNDVITrend(ndviCollection, region);
      
      return {
        monthly: monthlyNDVI,
        seasonal: seasonalNDVI,
        trend: trend
      };
      
    } catch (error) {
      throw new Error(`Failed to create temporal analysis: ${error.message}`);
    }
  }

  /**
   * Calculate NDVI trend over time
   */
  async calculateNDVITrend(ndviCollection, region) {
    try {
      const collectionSize = await this.ee.getCollectionSize(ndviCollection);
      
      if (collectionSize < 3) {
        return {
          available: false,
          reason: 'Insufficient data for trend analysis (minimum 3 images required)'
        };
      }
      
      // Add time band to each image
      const collectionWithTime = ndviCollection.map((image) => {
        const timeRadians = image.date().difference(ee.Date('1970-01-01'), 'year');
        const timeImage = ee.Image(timeRadians).rename('time').float();
        return image.addBands(timeImage);
      });
      
      // Calculate linear trend
      const linearTrend = collectionWithTime
        .select(['time', 'NDVI'])
        .reduce(ee.Reducer.linearRegression(1, 1));
      
      // Extract slope and intercept
      const slope = linearTrend.select('scale').clip(region);
      const intercept = linearTrend.select('offset').clip(region);
      
      // Get regional trend statistics
      const slopeStats = await this.getRegionalStatistics(slope, region);
      const interceptStats = await this.getRegionalStatistics(intercept, region);
      
      return {
        available: true,
        slope: slopeStats,
        intercept: interceptStats,
        interpretation: this.interpretTrend(slopeStats.mean)
      };
      
    } catch (error) {
      return {
        available: false,
        error: error.message
      };
    }
  }

  /**
   * Interpret NDVI trend slope
   */
  interpretTrend(slope) {
    if (slope > 0.001) {
      return 'Increasing vegetation health/density';
    } else if (slope < -0.001) {
      return 'Decreasing vegetation health/density';
    } else {
      return 'Stable vegetation conditions';
    }
  }

  /**
   * Get regional statistics for an image
   */
  async getRegionalStatistics(image, region) {
    try {
      const stats = image.reduceRegion({
        reducer: ee.Reducer.mean()
          .combine(ee.Reducer.median(), '', true)
          .combine(ee.Reducer.stdDev(), '', true)
          .combine(ee.Reducer.min(), '', true)
          .combine(ee.Reducer.max(), '', true)
          .combine(ee.Reducer.count(), '', true),
        geometry: region,
        scale: this.ndviConfig.scale,
        maxPixels: 1e9,
        bestEffort: true
      });
      
      return new Promise((resolve, reject) => {
        stats.evaluate((result, error) => {
          if (error) {
            reject(new Error(`Failed to get regional statistics: ${error.message}`));
          } else {
            resolve(result);
          }
        });
      });
      
    } catch (error) {
      throw new Error(`Regional statistics calculation failed: ${error.message}`);
    }
  }

  /**
   * Export NDVI data as numpy array
   */
  async exportNDVIAsNumpy(ndviImage, cell, outputDir, suffix = '') {
    try {
      console.log(`   📊 Exporting NDVI as numpy array for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      
      // Export parameters for numpy format
      const exportParams = {
        region: region,
        scale: this.ndviConfig.scale,
        maxPixels: 1e10,
        format: 'NPY'
      };
      
      const downloadUrl = await this.ee.exportNDVIArrayToNumpy(ndviImage, region, this.ndviConfig.scale);
      
      if (!downloadUrl) {
        throw new Error('Failed to generate numpy export URL');
      }
      
      // Download numpy file
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `${this.config.get('area.name')}_ndvi${suffix}_${timestamp}.npy`;
      const filepath = path.join(outputDir, filename);
      
      console.log(`   📥 Downloading numpy array to: ${filename}`);
      await this.downloadFile(downloadUrl, filepath);
      
      const stats = fs.statSync(filepath);
      const fileSizeMB = stats.size / (1024 * 1024);
      
      console.log(`   ✅ NDVI numpy export completed: ${fileSizeMB.toFixed(2)} MB`);
      
      return {
        success: true,
        filepath: filepath,
        filename: filename,
        fileSize: fileSizeMB,
        format: 'numpy',
        type: 'ndvi_array'
      };
      
    } catch (error) {
      console.error(`   ❌ NDVI numpy export failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Create vegetation health assessment based on NDVI
   */
  createVegetationHealthAssessment(ndviStats) {
    const meanNDVI = ndviStats.regional.NDVI_mean_mean || ndviStats.regional.mean;
    
    let healthCategory;
    let healthScore;
    let recommendations = [];
    
    if (meanNDVI >= 0.6) {
      healthCategory = 'Excellent';
      healthScore = 95;
      recommendations.push('Vegetation is in excellent condition');
      recommendations.push('Continue current management practices');
    } else if (meanNDVI >= 0.4) {
      healthCategory = 'Good';
      healthScore = 75;
      recommendations.push('Vegetation is in good condition');
      recommendations.push('Monitor for any declining trends');
    } else if (meanNDVI >= 0.2) {
      healthCategory = 'Fair';
      healthScore = 55;
      recommendations.push('Vegetation shows moderate health');
      recommendations.push('Consider irrigation or nutrient management');
    } else if (meanNDVI >= 0.1) {
      healthCategory = 'Poor';
      healthScore = 35;
      recommendations.push('Vegetation is stressed');
      recommendations.push('Investigate water, nutrient, or disease issues');
    } else {
      healthCategory = 'Critical';
      healthScore = 15;
      recommendations.push('Vegetation is in critical condition');
      recommendations.push('Immediate intervention required');
    }
    
    return {
      category: healthCategory,
      score: healthScore,
      meanNDVI: meanNDVI,
      recommendations: recommendations
    };
  }

  /**
   * Download file from URL
   */
  async downloadFile(url, filepath) {
    const https = require('https');
    
    return new Promise((resolve, reject) => {
      const file = fs.createWriteStream(filepath);
      const timeout = this.config.get('geeConfig.timeout') || 300000; // 5 minutes default
      
      const request = https.get(url, (response) => {
        if (response.statusCode !== 200) {
          reject(new Error(`HTTP ${response.statusCode}: ${response.statusMessage}`));
          return;
        }
        
        response.pipe(file);
        
        file.on('finish', () => {
          file.close();
          resolve();
        });
        
        file.on('error', (error) => {
          fs.unlink(filepath, () => {}); // Delete the file on error
          reject(error);
        });
      });
      
      request.setTimeout(timeout, () => {
        request.abort();
        reject(new Error(`Download timeout after ${timeout}ms`));
      });
      
      request.on('error', (error) => {
        reject(error);
      });
    });
  }
}

module.exports = NDVIProcessor;