/**
 * Metadata Manager Module for Test15
 * Handles metadata creation, management, and processing summaries
 */

const fs = require('fs');
const path = require('path');

class MetadataManager {
  constructor(config) {
    this.config = config;
  }

  /**
   * Create comprehensive metadata for a processed cell
   */
  createCellMetadata(cell, ndviResult, sensorResult, outputDir, processingStats = null) {
    try {
      console.log(`   📝 Creating metadata for cell ${cell.id}...`);
      
      const metadata = {
        // Basic cell information
        cell: {
          id: cell.id,
          bounds: cell.getBounds(),
          center: cell.getCenter(),
          areaKm2: cell.areaKm2,
          polygon: cell.polygon
        },
        
        // Processing information
        processing: {
          timestamp: new Date().toISOString(),
          processingTime: cell.processingTime,
          configuration: this.getProcessingConfiguration(),
          version: this.getSystemVersion()
        },
        
        // NDVI data information
        ndvi: this.createNDVIMetadata(ndviResult),
        
        // Sensor data information
        sensor: this.createSensorMetadata(sensorResult),
        
        // Output files information
        outputs: this.createOutputMetadata(cell, ndviResult, sensorResult, outputDir),
        
        // Quality assessment
        quality: this.createQualityAssessment(ndviResult, sensorResult),
        
        // Additional statistics
        statistics: processingStats || null
      };
      
      // Save metadata to file
      const metadataPath = path.join(outputDir, `${cell.id}_metadata.json`);
      fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2));
      
      console.log(`   ✅ Metadata created: ${path.basename(metadataPath)}`);
      
      return {
        success: true,
        metadata: metadata,
        filepath: metadataPath
      };
      
    } catch (error) {
      console.error(`   ❌ Metadata creation failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Create NDVI-specific metadata
   */
  createNDVIMetadata(ndviResult) {
    if (!ndviResult) {
      return { available: false, reason: 'NDVI data not processed' };
    }
    
    const ndviConfig = this.config.get('ndvi');
    
    return {
      available: true,
      satellite: ndviConfig.satellite,
      cloudThreshold: ndviConfig.cloudThreshold,
      scale: ndviConfig.scale,
      dateRange: ndviConfig.dateRangeMonths,
      imageCount: ndviResult.imageCount || 0,
      processingDate: ndviResult.processingDate || null,
      bands: ndviResult.bands || ['NDVI'],
      file: {
        filename: ndviResult.filename,
        sizeMB: ndviResult.fileSize,
        format: ndviResult.type || 'tif'
      },
      quality: {
        dataAvailable: ndviResult.success,
        imageQuality: this.assessNDVIQuality(ndviResult)
      }
    };
  }

  /**
   * Create sensor-specific metadata
   */
  createSensorMetadata(sensorResult) {
    if (!sensorResult) {
      return { available: false, reason: 'Sensor data not processed' };
    }
    
    const sensorConfig = this.config.get('sensor');
    
    return {
      available: true,
      scale: sensorConfig.scale,
      assets: sensorConfig.assets,
      targetBandsPerSensor: sensorConfig.targetBandsPerSensor || 4,
      totalSensors: sensorResult.sensorCount || 5,
      totalBands: sensorResult.bands ? sensorResult.bands.length : 20,
      bands: sensorResult.bands || [],
      sensorDetails: sensorResult.sensorResults || {},
      file: {
        filename: sensorResult.filename,
        sizeMB: sensorResult.fileSize,
        format: sensorResult.type || 'tif'
      },
      validation: sensorConfig.validation,
      quality: {
        dataAvailable: sensorResult.success,
        sensorsLoaded: sensorResult.sensorCount || 0,
        expectedSensors: 5
      }
    };
  }

  /**
   * Create output files metadata
   */
  createOutputMetadata(cell, ndviResult, sensorResult, outputDir) {
    const outputs = {
      directory: outputDir,
      files: []
    };
    
    // Add NDVI file if available
    if (ndviResult && ndviResult.filepath) {
      outputs.files.push({
        type: 'ndvi',
        filename: ndviResult.filename,
        filepath: ndviResult.filepath,
        sizeMB: ndviResult.fileSize,
        bands: ndviResult.bands || ['NDVI'],
        format: 'GeoTIFF'
      });
    }
    
    // Add sensor file if available
    if (sensorResult && sensorResult.filepath) {
      outputs.files.push({
        type: 'sensor',
        filename: sensorResult.filename,
        filepath: sensorResult.filepath,
        sizeMB: sensorResult.fileSize,
        bands: sensorResult.bands || [],
        format: 'GeoTIFF'
      });
    }
    
    // Add stacked file if it's a stacked result
    if (ndviResult && ndviResult.type === 'stacked') {
      outputs.files.push({
        type: 'stacked_ndvi_sensor',
        filename: ndviResult.filename,
        filepath: ndviResult.filepath,
        sizeMB: ndviResult.fileSize,
        totalBands: ndviResult.totalBands || 21,
        ndviBands: ndviResult.ndviBands || 1,
        sensorBands: ndviResult.sensorBands || 20,
        bands: ndviResult.bands || [],
        format: 'GeoTIFF'
      });
    }
    
    // Add metadata file
    outputs.files.push({
      type: 'metadata',
      filename: `${cell.id}_metadata.json`,
      filepath: path.join(outputDir, `${cell.id}_metadata.json`),
      format: 'JSON'
    });
    
    return outputs;
  }

  /**
   * Create quality assessment
   */
  createQualityAssessment(ndviResult, sensorResult) {
    const assessment = {
      overall: 'unknown',
      scores: {},
      issues: [],
      recommendations: []
    };
    
    let totalScore = 0;
    let maxScore = 0;
    
    // NDVI quality assessment
    if (ndviResult) {
      const ndviQuality = this.assessNDVIQuality(ndviResult);
      assessment.scores.ndvi = ndviQuality;
      totalScore += ndviQuality.score;
      maxScore += 100;
      
      if (ndviQuality.issues.length > 0) {
        assessment.issues.push(...ndviQuality.issues);
      }
    }
    
    // Sensor quality assessment
    if (sensorResult) {
      const sensorQuality = this.assessSensorQuality(sensorResult);
      assessment.scores.sensor = sensorQuality;
      totalScore += sensorQuality.score;
      maxScore += 100;
      
      if (sensorQuality.issues.length > 0) {
        assessment.issues.push(...sensorQuality.issues);
      }
    }
    
    // Calculate overall quality
    if (maxScore > 0) {
      const overallScore = (totalScore / maxScore) * 100;
      
      if (overallScore >= 90) {
        assessment.overall = 'excellent';
      } else if (overallScore >= 75) {
        assessment.overall = 'good';
      } else if (overallScore >= 60) {
        assessment.overall = 'fair';
      } else if (overallScore >= 40) {
        assessment.overall = 'poor';
      } else {
        assessment.overall = 'critical';
      }
      
      assessment.overallScore = parseFloat(overallScore.toFixed(1));
    }
    
    // Generate recommendations
    assessment.recommendations = this.generateQualityRecommendations(assessment);
    
    return assessment;
  }

  /**
   * Assess NDVI data quality
   */
  assessNDVIQuality(ndviResult) {
    const quality = {
      score: 0,
      category: 'unknown',
      issues: [],
      metrics: {}
    };
    
    // Check data availability
    if (!ndviResult.success) {
      quality.issues.push('NDVI data download failed');
      quality.score = 0;
      quality.category = 'failed';
      return quality;
    }
    
    // Check image count
    const imageCount = ndviResult.imageCount || 0;
    quality.metrics.imageCount = imageCount;
    
    if (imageCount === 0) {
      quality.issues.push('No NDVI images found for the specified time period');
      quality.score = 10;
    } else if (imageCount < 3) {
      quality.issues.push('Limited NDVI images available (< 3)');
      quality.score = 50;
    } else if (imageCount < 10) {
      quality.score = 75;
    } else {
      quality.score = 95;
    }
    
    // Check file size
    const fileSize = ndviResult.fileSize || 0;
    quality.metrics.fileSizeMB = fileSize;
    
    if (fileSize < 0.1) {
      quality.issues.push('NDVI file size unusually small');
      quality.score = Math.min(quality.score, 30);
    } else if (fileSize > 100) {
      quality.issues.push('NDVI file size unusually large');
    }
    
    // Determine category
    if (quality.score >= 80) {
      quality.category = 'excellent';
    } else if (quality.score >= 60) {
      quality.category = 'good';
    } else if (quality.score >= 40) {
      quality.category = 'fair';
    } else if (quality.score >= 20) {
      quality.category = 'poor';
    } else {
      quality.category = 'critical';
    }
    
    return quality;
  }

  /**
   * Assess sensor data quality
   */
  assessSensorQuality(sensorResult) {
    const quality = {
      score: 0,
      category: 'unknown',
      issues: [],
      metrics: {}
    };
    
    // Check data availability
    if (!sensorResult.success) {
      quality.issues.push('Sensor data download failed');
      quality.score = 0;
      quality.category = 'failed';
      return quality;
    }
    
    // Check sensor count
    const sensorCount = sensorResult.sensorCount || 0;
    const expectedSensors = 5; // ECe, N, P, pH, OC
    quality.metrics.sensorsLoaded = sensorCount;
    quality.metrics.expectedSensors = expectedSensors;
    
    if (sensorCount === 0) {
      quality.issues.push('No sensor data could be loaded');
      quality.score = 0;
    } else if (sensorCount < expectedSensors) {
      quality.issues.push(`Only ${sensorCount}/${expectedSensors} sensors loaded successfully`);
      quality.score = (sensorCount / expectedSensors) * 80; // Max 80% if not all sensors
    } else {
      quality.score = 95;
    }
    
    // Check band count
    const bandCount = sensorResult.bands ? sensorResult.bands.length : 0;
    const expectedBands = expectedSensors * 4; // 4 bands per sensor
    quality.metrics.bandsLoaded = bandCount;
    quality.metrics.expectedBands = expectedBands;
    
    if (bandCount < expectedBands) {
      quality.issues.push(`Expected ${expectedBands} bands, got ${bandCount}`);
      quality.score = Math.min(quality.score, (bandCount / expectedBands) * 90);
    }
    
    // Check file size
    const fileSize = sensorResult.fileSize || 0;
    quality.metrics.fileSizeMB = fileSize;
    
    if (fileSize < 0.1) {
      quality.issues.push('Sensor file size unusually small');
      quality.score = Math.min(quality.score, 30);
    }
    
    // Determine category
    if (quality.score >= 80) {
      quality.category = 'excellent';
    } else if (quality.score >= 60) {
      quality.category = 'good';
    } else if (quality.score >= 40) {
      quality.category = 'fair';
    } else if (quality.score >= 20) {
      quality.category = 'poor';
    } else {
      quality.category = 'critical';
    }
    
    return quality;
  }

  /**
   * Generate quality-based recommendations
   */
  generateQualityRecommendations(assessment) {
    const recommendations = [];
    
    // Overall recommendations
    switch (assessment.overall) {
      case 'excellent':
        recommendations.push('Data quality is excellent. Proceed with analysis.');
        break;
      case 'good':
        recommendations.push('Data quality is good. Minor issues may be present.');
        break;
      case 'fair':
        recommendations.push('Data quality is acceptable but may require caution in analysis.');
        break;
      case 'poor':
        recommendations.push('Data quality is poor. Consider reprocessing or different time periods.');
        break;
      case 'critical':
        recommendations.push('Data quality is critical. Reprocessing strongly recommended.');
        break;
    }
    
    // Specific recommendations based on issues
    for (const issue of assessment.issues) {
      if (issue.includes('No NDVI images')) {
        recommendations.push('Try extending the date range or reducing cloud threshold for NDVI.');
      } else if (issue.includes('Limited NDVI images')) {
        recommendations.push('Consider expanding the temporal window for better NDVI coverage.');
      } else if (issue.includes('sensors loaded')) {
        recommendations.push('Check sensor asset availability and network connectivity.');
      } else if (issue.includes('file size unusually small')) {
        recommendations.push('Verify data integrity and check for processing errors.');
      }
    }
    
    return [...new Set(recommendations)]; // Remove duplicates
  }

  /**
   * Get processing configuration summary
   */
  getProcessingConfiguration() {
    return {
      area: this.config.get('area.name'),
      ndvi: {
        satellite: this.config.get('ndvi.satellite'),
        cloudThreshold: this.config.get('ndvi.cloudThreshold'),
        scale: this.config.get('ndvi.scale'),
        dateRangeMonths: this.config.get('ndvi.dateRangeMonths')
      },
      sensor: {
        scale: this.config.get('sensor.scale'),
        targetBandsPerSensor: this.config.get('sensor.targetBandsPerSensor')
      },
      processing: {
        enableBandStacking: this.config.get('processing.enableBandStacking'),
        downloadNDVI: this.config.get('processing.downloadNDVI'),
        downloadSensor: this.config.get('processing.downloadSensor')
      }
    };
  }

  /**
   * Get system version information
   */
  getSystemVersion() {
    return {
      system: 'Test15 - NDVI & Sensor Processing Pipeline',
      version: '1.0.0',
      earthEngine: '@google/earthengine v1.6.6',
      node: process.version,
      platform: process.platform
    };
  }

  /**
   * Create processing summary for entire run
   */
  createProcessingSummary(cells, gridAnalysis, processingStats, outputDir) {
    try {
      console.log('📊 Creating processing summary...');
      
      const summary = {
        // Basic information
        processing: {
          timestamp: new Date().toISOString(),
          area: this.config.get('area.name'),
          configuration: this.getProcessingConfiguration(),
          version: this.getSystemVersion()
        },
        
        // Grid information
        grid: {
          ...gridAnalysis,
          totalCells: cells.length
        },
        
        // Processing statistics
        statistics: {
          ...processingStats,
          cells: this.createCellSummary(cells)
        },
        
        // Quality assessment
        quality: this.createOverallQualityAssessment(cells),
        
        // File summary
        outputs: this.createOutputSummary(cells, outputDir)
      };
      
      // Save summary
      const summaryPath = path.join(outputDir, 'processing_summary.json');
      fs.writeFileSync(summaryPath, JSON.stringify(summary, null, 2));
      
      // Create human-readable report
      const reportPath = path.join(outputDir, 'processing_report.md');
      this.createMarkdownReport(summary, reportPath);
      
      console.log(`✅ Processing summary created: ${path.basename(summaryPath)}`);
      console.log(`📄 Human-readable report: ${path.basename(reportPath)}`);
      
      return {
        success: true,
        summary: summary,
        summaryPath: summaryPath,
        reportPath: reportPath
      };
      
    } catch (error) {
      console.error(`❌ Failed to create processing summary: ${error.message}`);
      throw error;
    }
  }

  /**
   * Create cell summary statistics
   */
  createCellSummary(cells) {
    const summary = {
      total: cells.length,
      processed: 0,
      failed: 0,
      skipped: 0,
      processingTimes: [],
      totalDataMB: 0
    };
    
    for (const cell of cells) {
      if (cell.processed) {
        summary.processed++;
        if (cell.processingTime) {
          summary.processingTimes.push(cell.processingTime);
        }
        
        // Add file sizes
        if (cell.ndviResult && cell.ndviResult.fileSize) {
          summary.totalDataMB += cell.ndviResult.fileSize;
        }
        if (cell.sensorResult && cell.sensorResult.fileSize) {
          summary.totalDataMB += cell.sensorResult.fileSize;
        }
      } else if (cell.error) {
        summary.failed++;
      } else {
        summary.skipped++;
      }
    }
    
    // Calculate processing time statistics
    if (summary.processingTimes.length > 0) {
      summary.avgProcessingTime = summary.processingTimes.reduce((a, b) => a + b, 0) / summary.processingTimes.length;
      summary.minProcessingTime = Math.min(...summary.processingTimes);
      summary.maxProcessingTime = Math.max(...summary.processingTimes);
    }
    
    summary.totalDataMB = parseFloat(summary.totalDataMB.toFixed(2));
    
    return summary;
  }

  /**
   * Create overall quality assessment
   */
  createOverallQualityAssessment(cells) {
    const processedCells = cells.filter(cell => cell.processed && cell.metadata);
    
    if (processedCells.length === 0) {
      return {
        overall: 'no_data',
        message: 'No cells were successfully processed'
      };
    }
    
    const qualityScores = processedCells
      .map(cell => cell.metadata.quality.overallScore)
      .filter(score => score !== undefined);
    
    if (qualityScores.length === 0) {
      return {
        overall: 'unknown',
        message: 'Quality scores not available'
      };
    }
    
    const avgScore = qualityScores.reduce((a, b) => a + b, 0) / qualityScores.length;
    const minScore = Math.min(...qualityScores);
    const maxScore = Math.max(...qualityScores);
    
    let overall;
    if (avgScore >= 80) {
      overall = 'excellent';
    } else if (avgScore >= 60) {
      overall = 'good';
    } else if (avgScore >= 40) {
      overall = 'fair';
    } else {
      overall = 'poor';
    }
    
    return {
      overall: overall,
      avgScore: parseFloat(avgScore.toFixed(1)),
      minScore: minScore,
      maxScore: maxScore,
      cellsAssessed: qualityScores.length
    };
  }

  /**
   * Create output summary
   */
  createOutputSummary(cells, outputDir) {
    const summary = {
      directory: outputDir,
      totalFiles: 0,
      totalSizeMB: 0,
      fileTypes: {}
    };
    
    for (const cell of cells) {
      if (cell.metadata && cell.metadata.outputs) {
        for (const file of cell.metadata.outputs.files) {
          summary.totalFiles++;
          if (file.sizeMB) {
            summary.totalSizeMB += file.sizeMB;
          }
          
          const type = file.type || 'unknown';
          summary.fileTypes[type] = (summary.fileTypes[type] || 0) + 1;
        }
      }
    }
    
    summary.totalSizeMB = parseFloat(summary.totalSizeMB.toFixed(2));
    
    return summary;
  }

  /**
   * Create human-readable markdown report
   */
  createMarkdownReport(summary, reportPath) {
    const report = `# Test15 Processing Report

## Overview
- **Area**: ${summary.processing.area}
- **Processing Date**: ${summary.processing.timestamp}
- **System**: ${summary.processing.version.system}

## Grid Information
- **Total Area**: ${summary.grid.totalAreaKm2.toFixed(2)} km²
- **Grid Size**: ${summary.grid.gridSize.rows} × ${summary.grid.gridSize.cols}
- **Total Cells**: ${summary.grid.totalCells}
- **Average Cell Area**: ${summary.grid.cellAreaKm2.toFixed(2)} km²

## Processing Results
- **Cells Processed**: ${summary.statistics.cells.processed}/${summary.statistics.cells.total}
- **Success Rate**: ${((summary.statistics.cells.processed / summary.statistics.cells.total) * 100).toFixed(1)}%
- **Failed Cells**: ${summary.statistics.cells.failed}
- **Total Data Generated**: ${summary.statistics.cells.totalDataMB} MB

## Quality Assessment
- **Overall Quality**: ${summary.quality.overall}
${summary.quality.avgScore ? `- **Average Score**: ${summary.quality.avgScore}/100` : ''}
${summary.quality.cellsAssessed ? `- **Cells Assessed**: ${summary.quality.cellsAssessed}` : ''}

## Output Summary
- **Total Files**: ${summary.outputs.totalFiles}
- **Total Size**: ${summary.outputs.totalSizeMB} MB
- **File Types**: ${Object.entries(summary.outputs.fileTypes).map(([type, count]) => `${type}: ${count}`).join(', ')}

## Configuration
### NDVI Settings
- **Satellite**: ${summary.processing.configuration.ndvi.satellite}
- **Cloud Threshold**: ${summary.processing.configuration.ndvi.cloudThreshold}%
- **Scale**: ${summary.processing.configuration.ndvi.scale}m
- **Date Range**: ${summary.processing.configuration.ndvi.dateRangeMonths} months

### Sensor Settings
- **Scale**: ${summary.processing.configuration.sensor.scale}m
- **Bands per Sensor**: ${summary.processing.configuration.sensor.targetBandsPerSensor}

---
*Generated by Test15 NDVI & Sensor Processing Pipeline*
`;
    
    fs.writeFileSync(reportPath, report);
  }
}

module.exports = MetadataManager;