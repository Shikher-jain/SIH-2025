/**
 * Data Downloader Module for Test15
 * Handles NDVI and sensor data downloading with optimization
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const ee = require('@google/earthengine');
const BandStacker = require('./band-stacker');

class DataDownloader {
  constructor(config, earthEngine) {
    this.config = config;
    this.ee = earthEngine;
    this.downloadQueue = [];
    this.activeDownloads = 0;
    this.maxConcurrentDownloads = 2;
    
    // Initialize band stacker
    this.bandStacker = new BandStacker(config, earthEngine);
  }

  /**
   * Download stacked NDVI + sensor data as single 21-band .tif (for main processing)
   */
  async downloadStackedNDVISensorData(cell, outputDir) {
    try {
      console.log(`   🔗 Starting stacked NDVI+Sensor data download for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const ndviConfig = this.config.get('ndvi');
      const sensorConfig = this.config.get('sensor');
      
      // Get date range for NDVI data
      const dateRange = this.calculateDateRange(
        ndviConfig.dateRangeMonths,
        this.config.get('processing.enableAdvancedDateFiltering')
      );
      
      console.log(`   📅 Date filtering mode: ${dateRange.mode}`);
      console.log(`   📅 ${dateRange.description}`);
      console.log(`   📅 Searching for NDVI images: ${dateRange.start} to ${dateRange.end}`);
      
      // Get NDVI collection
      let ndviCollection = this.ee.getNDVICollectionAdvanced(
        region,
        dateRange,
        ndviConfig.cloudThreshold,
        ndviConfig.satellite
      );
      
      // Check available images with progressive fallback
      let imageCount = await this.ee.getCollectionSize(ndviCollection);
      console.log(`   📊 Found ${imageCount} NDVI images (${ndviConfig.dateRangeMonths} months)`);
      
      if (imageCount === 0) {
        console.log(`   ⚠️ No NDVI images found. Trying extended search with fallback to 12-month range...`);
        
        // Create fallback 12-month range
        const extendedRange = this.calculateDateRange(12, false);
        console.log(`   📅 Extended search: ${extendedRange.start} to ${extendedRange.end}`);
        
        ndviCollection = this.ee.getNDVICollectionAdvanced(
          region,
          extendedRange,
          ndviConfig.cloudThreshold,
          ndviConfig.satellite
        );
        
        imageCount = await this.ee.getCollectionSize(ndviCollection);
        console.log(`   📊 Found ${imageCount} NDVI images (extended search)`);
        
        if (imageCount === 0) {
          throw new Error('No suitable NDVI images found in extended date range');
        }
      }
      
      // Get sensor assets
      const sensorImages = {};
      for (const [sensorName, assetId] of Object.entries(sensorConfig.assets)) {
        try {
          sensorImages[sensorName] = assetId;
        } catch (error) {
          console.warn(`   ⚠️ Failed to load ${sensorName}: ${error.message}`);
        }
      }
      
      // Create stacked image using BandStacker
      const stackedImage = await this.bandStacker.createStackedNDVISensorImage(
        cell, 
        ndviCollection, 
        sensorImages
      );
      
      // Download stacked image
      const result = await this.bandStacker.downloadStackedImage(
        stackedImage, 
        cell, 
        outputDir
      );
      
      console.log(`   ✅ Stacked NDVI+Sensor data download completed: ${result.fileSize.toFixed(2)} MB`);
      
      return {
        success: true,
        filepath: result.filepath,
        filename: result.filename,
        fileSize: result.fileSize,
        totalBands: 21,
        ndviBands: 1,
        sensorBands: 20,
        imageCount: imageCount,
        bands: result.bands,
        type: 'stacked'
      };
      
    } catch (error) {
      console.error(`   ❌ Stacked NDVI+Sensor data download failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Download stacked satellite + sensor data as single 26-band .tif
   */
  async downloadStackedSatelliteSensorData(cell, outputDir) {
    try {
      console.log(`   🔗 Starting stacked Satellite+Sensor data download for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const satelliteConfig = this.config.get('ndvi'); // Using ndvi config for satellite settings
      const sensorConfig = this.config.get('sensor');
      
      // Get date range for satellite data with enhanced filtering
      const dateRange = this.calculateDateRange(
        satelliteConfig.dateRangeMonths,
        this.config.get('processing.enableAdvancedDateFiltering')
      );
      
      console.log(`   📅 Date filtering mode: ${dateRange.mode}`);
      console.log(`   📅 ${dateRange.description}`);
      console.log(`   📅 Searching for satellite images: ${dateRange.start} to ${dateRange.end}`);
      
      // Get satellite collection (Landsat 8 with 6 bands)
      let satelliteCollection = this.getSatelliteCollection(
        region,
        dateRange,
        satelliteConfig.cloudThreshold,
        satelliteConfig.satellite
      );
      
      // Check available images with progressive fallback
      let imageCount = await this.ee.getCollectionSize(satelliteCollection);
      console.log(`   📊 Found ${imageCount} satellite images`);
      
      if (imageCount === 0) {
        console.log(`   ⚠️ No images found. Trying extended search with fallback to 6-month range...`);
        
        // Create fallback 6-month range  
        const extendedRange = this.calculateDateRange(6, false); // Force basic mode for fallback
        console.log(`   📅 Extended search: ${extendedRange.start} to ${extendedRange.end}`);
        
        satelliteCollection = this.getSatelliteCollection(
          region,
          extendedRange,
          satelliteConfig.cloudThreshold,
          satelliteConfig.satellite
        );
        
        imageCount = await this.ee.getCollectionSize(satelliteCollection);
        console.log(`   📊 Found ${imageCount} images (extended search)`);
        
        if (imageCount === 0) {
          throw new Error('No suitable satellite images found in extended date range');
        }
      }
      
      // Get sensor assets
      const sensorImages = {};
      for (const [sensorName, assetId] of Object.entries(sensorConfig.assets)) {
        try {
          sensorImages[sensorName] = assetId;
        } catch (error) {
          console.warn(`   ⚠️ Failed to load ${sensorName}: ${error.message}`);
        }
      }
      
      // Create stacked image using BandStacker
      const stackedImage = await this.bandStacker.createStackedSatelliteSensorImage(
        cell, 
        satelliteCollection, 
        sensorImages
      );
      
      // Download stacked image
      const result = await this.bandStacker.downloadStackedImage(
        stackedImage, 
        cell, 
        outputDir
      );
      
      console.log(`   ✅ Stacked Satellite+Sensor data download completed: ${result.fileSize.toFixed(2)} MB`);
      
      return {
        success: true,
        filepath: result.filepath,
        filename: result.filename,
        fileSize: result.fileSize,
        totalBands: 26,
        satelliteBands: 6,
        sensorBands: 20,
        imageCount: imageCount,
        bands: result.bands,
        type: 'stacked'
      };
      
    } catch (error) {
      console.error(`   ❌ Stacked Satellite+Sensor data download failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Get satellite collection (Landsat 8 with 6 bands: B2, B3, B4, B5, B8, B11)
   */
  getSatelliteCollection(region, dateRange, cloudThreshold, satellite = 'LANDSAT_8') {
    try {
      let collection;
      
      switch (satellite) {
        case 'LANDSAT_8':
          collection = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
            .filterBounds(region)
            .filterDate(dateRange.start, dateRange.end)
            .filter(ee.Filter.lt('CLOUD_COVER', cloudThreshold));
          break;
          
        case 'LANDSAT_9':
          collection = ee.ImageCollection('LANDSAT/LC09/C02/T1_L2')
            .filterBounds(region)
            .filterDate(dateRange.start, dateRange.end)
            .filter(ee.Filter.lt('CLOUD_COVER', cloudThreshold));
          break;
          
        default:
          throw new Error(`Unsupported satellite: ${satellite}`);
      }
      
      return collection;
      
    } catch (error) {
      throw new Error(`Failed to get satellite collection: ${error.message}`);
    }
  }

  /**
   * Download NDVI data as 512x512 numpy array for a cell
   */
  async downloadNDVIData(cell, outputDir) {
    try {
      console.log(`   🌱 Starting NDVI 512x512 numpy array download for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const ndviConfig = this.config.get('ndvi');
      
      // Get date range with enhanced filtering
      const dateRange = this.calculateDateRange(
        ndviConfig.dateRangeMonths, 
        this.config.get('processing.enableAdvancedDateFiltering')
      );
      
      console.log(`   📅 Date filtering mode: ${dateRange.mode}`);
      console.log(`   📅 ${dateRange.description}`);
      console.log(`   📅 Searching for images: ${dateRange.start} to ${dateRange.end}`);
      
      // Get NDVI collection with enhanced filtering
      let collection = this.ee.getNDVICollectionAdvanced(
        region,
        dateRange,
        ndviConfig.cloudThreshold,
        ndviConfig.satellite
      );
      
      // Check available images with progressive fallback
      let imageCount = await this.ee.getCollectionSize(collection);
      console.log(`   📊 Found ${imageCount} images (${ndviConfig.dateRangeMonths} months)`);
      
      // Progressive fallback for image availability
      if (imageCount === 0) {
        console.log(`   ⚠️ No images found. Trying extended search with fallback to 12-month range...`);
        
        // Create fallback 12-month range
        const extendedRange = this.calculateDateRange(12, false); // Force basic mode for fallback
        console.log(`   📅 Extended search: ${extendedRange.start} to ${extendedRange.end}`);
        
        collection = this.ee.getNDVICollectionAdvanced(
          region,
          extendedRange,
          ndviConfig.cloudThreshold,
          ndviConfig.satellite
        );
        
        imageCount = await this.ee.getCollectionSize(collection);
        console.log(`   📊 Found ${imageCount} images (extended search)`);
        
        if (imageCount === 0) {
          throw new Error('No suitable NDVI images found in extended date range');
        }
      }
      
      // Create median NDVI composite
      const ndviComposite = this.ee.createNDVIMedianComposite(collection, region);
      
      console.log(`   📅 NDVI composite created from ${imageCount} images`);
      
      // Configure export parameters for 512x512 numpy array at 10m resolution
      const outputDimensions = ndviConfig.outputDimensions;
      let exportParams;
      
      if (outputDimensions && outputDimensions.enabled) {
        // Use fixed pixel dimensions (512x512)
        exportParams = {
          dimensions: [outputDimensions.width, outputDimensions.height],
          crs: 'EPSG:4326',
          region: region,
          format: 'NPY'
        };
        console.log(`   🖼️ Using fixed dimensions: ${outputDimensions.width}x${outputDimensions.height} pixels`);
      } else {
        // Use scale-based export (fallback)
        exportParams = {
          region: region,
          scale: ndviConfig.scale,
          maxPixels: ndviConfig.maxPixels,
          format: 'NPY'
        };
        console.log(`   📏 Using scale-based export: ${ndviConfig.scale}m resolution`);
      }
      
      // Export NDVI as numpy array
      const downloadUrl = await this.ee.getDownloadUrl(ndviComposite.select('NDVI'), exportParams);
      
      if (!downloadUrl) {
        throw new Error('Failed to generate NDVI numpy download URL');
      }
      
      console.log('   ✅ NDVI numpy download URL generated');
      
      // Download file
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `${this.config.get('area.name')}_ndvi_${cell.id}_${timestamp}.npy`;
      const filepath = path.join(outputDir, filename);
      
      console.log(`   📥 Downloading numpy array to: ${filename}`);
      await this.downloadFile(downloadUrl, filepath);
      
      const stats = fs.statSync(filepath);
      const fileSizeMB = stats.size / (1024 * 1024);
      
      console.log(`   ✅ NDVI numpy download completed: ${fileSizeMB.toFixed(2)} MB`);
      console.log(`   📐 Expected dimensions: 512x512 pixels at 10m resolution`);
      
      return {
        success: true,
        filepath: filepath,
        filename: filename,
        fileSize: fileSizeMB,
        format: 'numpy',
        bands: ['NDVI'],
        imageCount: imageCount,
        dimensions: outputDimensions.enabled ? [outputDimensions.width, outputDimensions.height] : 'scale-based',
        resolution: ndviConfig.scale,
        type: 'ndvi_numpy'
      };
      
    } catch (error) {
      console.error(`   ❌ NDVI numpy download failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Download sensor data as 512x512 .tif (20 bands: 4 bands each for ECe, N, P, pH, OC)
   */
  async downloadSensorData(cell, outputDir) {
    try {
      console.log(`   📊 Starting sensor data download for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const sensorConfig = this.config.get('sensor');
      
      // Load and combine all sensor assets
      const validSensors = [];
      const sensorResults = {};
      
      for (const [sensorName, assetId] of Object.entries(sensorConfig.assets)) {
        try {
          console.log(`     📈 Loading ${sensorName} sensor data...`);
          
          const sensorImage = this.ee.getSensorImage(assetId);
          const imageInfo = await this.ee.getImageInfo(sensorImage);
          
          // Create proper band names based on configuration
          const bandConfig = sensorConfig.bandConfiguration[sensorName];
          let bandNames;
          
          if (bandConfig && bandConfig.bands) {
            bandNames = bandConfig.bands;
          } else {
            // Default to 4 bands per sensor
            bandNames = [`${sensorName}_mean`, `${sensorName}_median`, `${sensorName}_std`, `${sensorName}_max`];
          }
          
          // Ensure we have exactly 4 bands
          if (imageInfo.bands.length < 4) {
            console.warn(`     ⚠️ ${sensorName} has only ${imageInfo.bands.length} bands, expected 4`);
            // Pad with repeated bands if necessary
            while (bandNames.length < 4) {
              bandNames.push(`${sensorName}_band${bandNames.length + 1}`);
            }
          }
          
          // Take only first 4 bands
          bandNames = bandNames.slice(0, 4);
          
          const renamedImage = sensorImage.select(
            imageInfo.bands.slice(0, 4).map(band => band.id),
            bandNames
          );
          
          validSensors.push(renamedImage);
          sensorResults[sensorName] = {
            bands: bandNames,
            description: bandConfig ? bandConfig.description : `${sensorName} sensor data`
          };
          
          console.log(`     ✅ ${sensorName}: 4 bands loaded (${bandNames.join(', ')})`);
          
        } catch (error) {
          console.warn(`     ⚠️ Failed to load ${sensorName}: ${error.message}`);
          continue;
        }
      }
      
      if (validSensors.length === 0) {
        throw new Error('No sensor data could be loaded');
      }
      
      if (validSensors.length < 5) {
        console.warn(`   ⚠️ Only ${validSensors.length}/5 sensors loaded successfully`);
      }
      
      // Combine all sensor images and resample to 10m resolution
      let combinedSensorImage = ee.Image.cat(validSensors);
      
      // Resample from 1000m to 10m resolution
      combinedSensorImage = combinedSensorImage.reproject({
        crs: 'EPSG:4326',
        scale: sensorConfig.scale // 10m
      }).resample('bilinear');
      
      // Clip to region
      combinedSensorImage = combinedSensorImage.clip(region);
      
      console.log(`   🔍 Resampled sensor data from 1000m to ${sensorConfig.scale}m resolution`);
      
      // Configure download parameters for 512x512 sensor data
      const outputDimensions = sensorConfig.outputDimensions;
      let downloadParams;
      
      if (outputDimensions && outputDimensions.enabled) {
        // Use fixed pixel dimensions (512x512)
        downloadParams = {
          dimensions: [outputDimensions.width, outputDimensions.height],
          crs: 'EPSG:4326',
          region: region,
          format: 'GEO_TIFF',
          formatOptions: {
            cloudOptimized: true,
            noData: -9999
          }
        };
        console.log(`   🖼️ Using fixed dimensions: ${outputDimensions.width}x${outputDimensions.height} pixels`);
      } else {
        // Use scale-based export (fallback)
        downloadParams = {
          scale: sensorConfig.scale,
          region: region,
          maxPixels: sensorConfig.maxPixels,
          format: 'GEO_TIFF',
          formatOptions: {
            cloudOptimized: true,
            noData: -9999
          }
        };
        console.log(`   📏 Using scale-based export: ${sensorConfig.scale}m resolution`);
      }
      
      const downloadUrl = await this.ee.getDownloadUrl(combinedSensorImage, downloadParams);
      
      if (!downloadUrl) {
        throw new Error('Failed to generate sensor data download URL');
      }
      
      console.log('   ✅ Sensor data download URL generated');
      
      // Download file
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `${this.config.get('area.name')}_sensor_${cell.id}_${timestamp}.tif`;
      const filepath = path.join(outputDir, filename);
      
      console.log(`   📥 Downloading to: ${filename}`);
      await this.downloadFile(downloadUrl, filepath);
      
      const stats = fs.statSync(filepath);
      const fileSizeMB = stats.size / (1024 * 1024);
      
      const allBandNames = Object.values(sensorResults).flatMap(sensor => sensor.bands);
      
      console.log(`   ✅ Sensor data download completed: ${fileSizeMB.toFixed(2)} MB`);
      console.log(`   📊 Total bands: ${allBandNames.length} (${validSensors.length} sensors × 4 bands each)`);
      console.log(`   📐 Expected dimensions: 512x512 pixels at 10m resolution`);
      
      return {
        success: true,
        filepath: filepath,
        filename: filename,
        fileSize: fileSizeMB,
        bands: allBandNames,
        sensorCount: validSensors.length,
        sensorResults: sensorResults,
        dimensions: outputDimensions.enabled ? [outputDimensions.width, outputDimensions.height] : 'scale-based',
        resolution: sensorConfig.scale,
        type: 'sensor'
      };
      
    } catch (error) {
      console.error(`   ❌ Sensor data download failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Calculate date range for data filtering
   */
  calculateDateRange(months, enableAdvancedFiltering = false) {
    const ndviConfig = this.config.get('ndvi');
    
    if (enableAdvancedFiltering && ndviConfig.dateFiltering) {
      const dateFiltering = ndviConfig.dateFiltering;
      
      // Specific month/year mode
      if (dateFiltering.specificMonthYear && dateFiltering.specificMonthYear.enabled) {
        const periods = dateFiltering.specificMonthYear.periods;
        if (periods && periods.length > 0) {
          // Use first and last periods to create range
          const firstPeriod = periods[0];
          const lastPeriod = periods[periods.length - 1];
          
          const startDate = new Date(firstPeriod.year, firstPeriod.month - 1, 1);
          const endDate = new Date(lastPeriod.year, lastPeriod.month, 0);
          
          return {
            start: startDate.toISOString().split('T')[0],
            end: endDate.toISOString().split('T')[0],
            mode: 'specificMonthYear',
            periods: periods,
            description: `Specific periods: ${periods.map(p => p.description).join(', ')}`
          };
        }
      }
      
      // Seasonal filtering mode
      if (dateFiltering.seasonalFiltering && dateFiltering.seasonalFiltering.enabled) {
        const { months, years, description } = dateFiltering.seasonalFiltering;
        // For simplicity, use the full range of years and months
        const startYear = Math.min(...years);
        const endYear = Math.max(...years);
        const startMonth = Math.min(...months);
        const endMonth = Math.max(...months);
        
        return {
          start: `${startYear}-${String(startMonth).padStart(2, '0')}-01`,
          end: `${endYear}-${String(endMonth).padStart(2, '0')}-28`,
          mode: 'seasonalFiltering',
          description: description || 'Seasonal filtering'
        };
      }
      
      // Custom date range mode
      if (dateFiltering.customDateRange && dateFiltering.customDateRange.enabled) {
        const { startDate, endDate, description } = dateFiltering.customDateRange;
        return {
          start: startDate,
          end: endDate,
          mode: 'customDateRange',
          description: description || 'Custom date range'
        };
      }
    }
    
    // Default mode - recent months
    const endDate = new Date();
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - months);
    
    return {
      start: startDate.toISOString().split('T')[0],
      end: endDate.toISOString().split('T')[0],
      mode: 'recent',
      description: `Recent ${months} months`
    };
  }

  /**
   * Download file from URL
   */
  async downloadFile(url, filepath) {
    return new Promise((resolve, reject) => {
      const file = fs.createWriteStream(filepath);
      const timeout = this.config.get('geeConfig.timeout') || 300000; // 5 minutes default
      
      const request = https.get(url, (response) => {
        if (response.statusCode !== 200) {
          reject(new Error(`HTTP ${response.statusCode}: ${response.statusMessage}`));
          return;
        }
        
        response.pipe(file);
        
        file.on('finish', () => {
          file.close();
          resolve();
        });
        
        file.on('error', (error) => {
          fs.unlink(filepath, () => {}); // Delete the file on error
          reject(error);
        });
      });
      
      request.setTimeout(timeout, () => {
        request.abort();
        reject(new Error(`Download timeout after ${timeout}ms`));
      });
      
      request.on('error', (error) => {
        reject(error);
      });
    });
  }
}

module.exports = DataDownloader;