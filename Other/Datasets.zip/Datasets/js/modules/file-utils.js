/**
 * File Utilities Module for Test15
 * Handles file operations, directory management, and data organization
 */

const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

/**
 * Convert satellite.tif to PNG heatmap
 * @param {string} tiffPath - Input GeoTIFF file path
 * @param {string} outputDir - Directory to save PNG heatmap
 * @param {string} outputName - Output PNG file name (without extension)
 */
async function convertTiffToHeatmapPNG(tiffPath, outputDir, outputName = 'heatmap') {
  try {
    const pngPath = path.join(outputDir, `${outputName}.png`);
    
    // Load TIFF, convert to greyscale heatmap-like (color mapping can be enhanced)
    await sharp(tiffPath)
      .resize(800)  // optional resize for performance
      .toColourspace('b-w') // convert to grayscale for heatmap base
      .png()
      .toFile(pngPath);

    console.log(`🌡️ Heatmap PNG generated at: ${pngPath}`);
    return pngPath;
  } catch (error) {
    console.error('❌ Failed to convert TIFF to heatmap PNG:', error);
    throw error;
  }
}

module.exports = {
  convertTiffToHeatmapPNG,
  // other exports...
};

class FileUtils {
  constructor(config) {
    this.config = config;
  }

  /**
   * Create cell output directory
   */
  createCellOutputDir(cellId, baseOutputDir) {
    try {
      const cellDir = path.join(baseOutputDir, `cells`, cellId);
      
      if (!fs.existsSync(cellDir)) {
        fs.mkdirSync(cellDir, { recursive: true });
      }
      
      return cellDir;
      
    } catch (error) {
      throw new Error(`Failed to create cell directory: ${error.message}`);
    }
  }

  /**
   * Check for existing data in cell directory
   */
  checkExistingData(cellDir) {
    try {
      const existing = {
        ndvi: false,
        sensor: false,
        stacked: false,
        metadata: false,
        numpy: false
      };
      
      if (!fs.existsSync(cellDir)) {
        return existing;
      }
      
      const files = fs.readdirSync(cellDir);
      
      for (const file of files) {
        const lowerFile = file.toLowerCase();
        
        if (lowerFile.includes('ndvi') && lowerFile.endsWith('.tif')) {
          existing.ndvi = true;
        }
        
        if (lowerFile.includes('sensor') && lowerFile.endsWith('.tif')) {
          existing.sensor = true;
        }
        
        if (lowerFile.includes('21bands') || (lowerFile.includes('ndvi') && lowerFile.includes('sensor'))) {
          existing.stacked = true;
        }
        
        if (lowerFile.includes('metadata') && lowerFile.endsWith('.json')) {
          existing.metadata = true;
        }
        
        if (lowerFile.includes('ndvi') && lowerFile.endsWith('.npy')) {
          existing.numpy = true;
        }
      }
      
      return existing;
      
    } catch (error) {
      console.warn(`Failed to check existing data: ${error.message}`);
      return {
        ndvi: false,
        sensor: false,
        stacked: false,
        metadata: false,
        numpy: false
      };
    }
  }

  /**
   * Create file manifest for the output directory
   */
  createFileManifest(outputDir, manifestPath) {
    try {
      console.log(`📋 Creating file manifest...`);
      
      const manifest = {
        created: new Date().toISOString(),
        outputDirectory: outputDir,
        area: this.config.get('area.name'),
        summary: {
          totalFiles: 0,
          totalSizeMB: 0,
          fileTypes: {}
        },
        cells: {},
        globalFiles: []
      };
      
      // Scan output directory
      this.scanDirectory(outputDir, outputDir, manifest);
      
      // Calculate summary
      manifest.summary.totalFiles = this.countTotalFiles(manifest);
      manifest.summary.totalSizeMB = parseFloat(this.calculateTotalSize(manifest).toFixed(2));
      
      // Save manifest
      fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
      
      console.log(`✅ File manifest created: ${manifestPath}`);
      
      return manifest;
      
    } catch (error) {
      console.error(`❌ Failed to create file manifest: ${error.message}`);
      throw error;
    }
  }

  /**
   * Recursively scan directory for files
   */
  scanDirectory(dirPath, basePath, manifest, relativePath = '') {
    try {
      if (!fs.existsSync(dirPath)) {
        return;
      }
      
      const items = fs.readdirSync(dirPath);
      
      for (const item of items) {
        const itemPath = path.join(dirPath, item);
        const relativeItemPath = path.join(relativePath, item);
        const stats = fs.statSync(itemPath);
        
        if (stats.isDirectory()) {
          // Handle cell directories specially
          if (relativePath === 'cells' || (relativePath === '' && item === 'cells')) {
            // This is a cell directory
            if (relativePath === 'cells') {
              manifest.cells[item] = this.scanCellDirectory(itemPath);
            } else {
              this.scanDirectory(itemPath, basePath, manifest, item);
            }
          } else {
            this.scanDirectory(itemPath, basePath, manifest, relativeItemPath);
          }
        } else {
          // Regular file
          const fileInfo = this.getFileInfo(itemPath, relativeItemPath);
          
          if (relativePath.startsWith('cells')) {
            // This file belongs to a cell - will be handled by scanCellDirectory
            continue;
          } else {
            // Global file
            manifest.globalFiles.push(fileInfo);
            this.updateFileTypeCounts(manifest.summary.fileTypes, fileInfo.extension);
          }
        }
      }
      
    } catch (error) {
      console.warn(`Failed to scan directory ${dirPath}: ${error.message}`);
    }
  }

  /**
   * Scan individual cell directory
   */
  scanCellDirectory(cellDir) {
    const cellInfo = {
      files: [],
      summary: {
        totalFiles: 0,
        totalSizeMB: 0,
        hasNDVI: false,
        hasSensor: false,
        hasStacked: false,
        hasMetadata: false,
        hasNumpy: false
      }
    };
    
    try {
      const files = fs.readdirSync(cellDir);
      
      for (const file of files) {
        const filePath = path.join(cellDir, file);
        const stats = fs.statSync(filePath);
        
        if (stats.isFile()) {
          const fileInfo = this.getFileInfo(filePath, file);
          cellInfo.files.push(fileInfo);
          
          // Update cell summary
          const lowerFile = file.toLowerCase();
          if (lowerFile.includes('ndvi') && lowerFile.endsWith('.tif')) {
            cellInfo.summary.hasNDVI = true;
          }
          if (lowerFile.includes('sensor') && lowerFile.endsWith('.tif')) {
            cellInfo.summary.hasSensor = true;
          }
          if (lowerFile.includes('21bands') || (lowerFile.includes('ndvi') && lowerFile.includes('sensor'))) {
            cellInfo.summary.hasStacked = true;
          }
          if (lowerFile.includes('metadata') && lowerFile.endsWith('.json')) {
            cellInfo.summary.hasMetadata = true;
          }
          if (lowerFile.includes('ndvi') && lowerFile.endsWith('.npy')) {
            cellInfo.summary.hasNumpy = true;
          }
        }
      }
      
      cellInfo.summary.totalFiles = cellInfo.files.length;
      cellInfo.summary.totalSizeMB = parseFloat(
        cellInfo.files.reduce((sum, file) => sum + file.sizeMB, 0).toFixed(2)
      );
      
    } catch (error) {
      console.warn(`Failed to scan cell directory ${cellDir}: ${error.message}`);
    }
    
    return cellInfo;
  }

  /**
   * Get file information
   */
  getFileInfo(filePath, relativePath) {
    const stats = fs.statSync(filePath);
    const extension = path.extname(filePath).toLowerCase();
    
    return {
      name: path.basename(filePath),
      relativePath: relativePath,
      sizeMB: parseFloat((stats.size / (1024 * 1024)).toFixed(2)),
      sizeBytes: stats.size,
      extension: extension,
      created: stats.birthtime.toISOString(),
      modified: stats.mtime.toISOString(),
      type: this.getFileType(extension)
    };
  }

  /**
   * Determine file type based on extension
   */
  getFileType(extension) {
    const typeMap = {
      '.tif': 'GeoTIFF',
      '.tiff': 'GeoTIFF',
      '.npy': 'NumPy Array',
      '.json': 'JSON Metadata',
      '.txt': 'Text',
      '.png': 'PNG Image',
      '.jpg': 'JPEG Image',
      '.jpeg': 'JPEG Image',
      '.pdf': 'PDF Document',
      '.csv': 'CSV Data',
      '.xlsx': 'Excel Spreadsheet'
    };
    
    return typeMap[extension] || 'Unknown';
  }

  /**
   * Update file type counts
   */
  updateFileTypeCounts(fileTypes, extension) {
    const type = this.getFileType(extension);
    fileTypes[type] = (fileTypes[type] || 0) + 1;
  }

  /**
   * Count total files in manifest
   */
  countTotalFiles(manifest) {
    let total = manifest.globalFiles.length;
    
    for (const cellInfo of Object.values(manifest.cells)) {
      total += cellInfo.summary.totalFiles;
    }
    
    return total;
  }

  /**
   * Calculate total size in manifest
   */
  calculateTotalSize(manifest) {
    let total = manifest.globalFiles.reduce((sum, file) => sum + file.sizeMB, 0);
    
    for (const cellInfo of Object.values(manifest.cells)) {
      total += cellInfo.summary.totalSizeMB;
    }
    
    return total;
  }

  /**
   * Clean up temporary files
   */
  cleanupTempFiles(cellDir) {
    try {
      const tempPatterns = ['.tmp', '.temp', '.download'];
      
      if (!fs.existsSync(cellDir)) {
        return;
      }
      
      const files = fs.readdirSync(cellDir);
      let cleaned = 0;
      
      for (const file of files) {
        const filePath = path.join(cellDir, file);
        const shouldDelete = tempPatterns.some(pattern => file.includes(pattern));
        
        if (shouldDelete) {
          try {
            fs.unlinkSync(filePath);
            cleaned++;
          } catch (error) {
            console.warn(`Failed to delete temp file ${file}: ${error.message}`);
          }
        }
      }
      
      if (cleaned > 0) {
        console.log(`🧹 Cleaned up ${cleaned} temporary files in ${cellDir}`);
      }
      
    } catch (error) {
      console.warn(`Failed to cleanup temp files: ${error.message}`);
    }
  }

  /**
   * Validate file integrity
   */
  validateFileIntegrity(filePath, expectedSizeBytes = null) {
    try {
      if (!fs.existsSync(filePath)) {
        return { valid: false, error: 'File does not exist' };
      }
      
      const stats = fs.statSync(filePath);
      
      if (stats.size === 0) {
        return { valid: false, error: 'File is empty' };
      }
      
      if (expectedSizeBytes && Math.abs(stats.size - expectedSizeBytes) > 1024) {
        return { 
          valid: false, 
          error: `File size mismatch: expected ${expectedSizeBytes}, got ${stats.size}` 
        };
      }
      
      return { valid: true, size: stats.size };
      
    } catch (error) {
      return { valid: false, error: error.message };
    }
  }

  /**
   * Create directory structure for organized output
   */
  createOutputStructure(baseDir) {
    try {
      const dirs = [
        'cells',
        'summaries',
        'visualizations',
        'logs',
        'metadata'
      ];
      
      for (const dir of dirs) {
        const dirPath = path.join(baseDir, dir);
        if (!fs.existsSync(dirPath)) {
          fs.mkdirSync(dirPath, { recursive: true });
        }
      }
      
      return true;
      
    } catch (error) {
      console.error(`Failed to create output structure: ${error.message}`);
      return false;
    }
  }

  /**
   * Archive completed cell data
   */
  archiveCellData(cellDir, archiveDir) {
    try {
      if (!fs.existsSync(cellDir)) {
        throw new Error('Cell directory does not exist');
      }
      
      const cellName = path.basename(cellDir);
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const archiveName = `${cellName}_${timestamp}`;
      const targetDir = path.join(archiveDir, archiveName);
      
      // Create archive directory
      if (!fs.existsSync(archiveDir)) {
        fs.mkdirSync(archiveDir, { recursive: true });
      }
      
      // Copy cell directory to archive
      this.copyDirectory(cellDir, targetDir);
      
      console.log(`📦 Cell data archived: ${targetDir}`);
      
      return targetDir;
      
    } catch (error) {
      console.error(`Failed to archive cell data: ${error.message}`);
      throw error;
    }
  }

  /**
   * Copy directory recursively
   */
  copyDirectory(source, target) {
    if (!fs.existsSync(target)) {
      fs.mkdirSync(target, { recursive: true });
    }
    
    const items = fs.readdirSync(source);
    
    for (const item of items) {
      const sourcePath = path.join(source, item);
      const targetPath = path.join(target, item);
      const stats = fs.statSync(sourcePath);
      
      if (stats.isDirectory()) {
        this.copyDirectory(sourcePath, targetPath);
      } else {
        fs.copyFileSync(sourcePath, targetPath);
      }
    }
  }

  /**
   * Get disk space information
   */
  getDiskSpaceInfo(dirPath) {
    try {
      const stats = fs.statSync(dirPath);
      // Note: This is a simplified version. For accurate disk space info,
      // you would need a platform-specific implementation or external library
      
      return {
        available: true,
        path: dirPath,
        note: 'Use platform-specific tools for accurate disk space information'
      };
      
    } catch (error) {
      return {
        available: false,
        error: error.message
      };
    }
  }
}

module.exports = FileUtils;