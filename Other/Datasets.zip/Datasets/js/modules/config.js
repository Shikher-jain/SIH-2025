/**
 * Configuration Manager Module
 * Handles loading and validating configuration for Test15 NDVI & Sensor processing
 */

const fs = require('fs');
const path = require('path');

class ConfigManager {
  constructor(configPath) {
    this.configPath = configPath;
    this.config = this.loadConfig();
    this.validateConfig();
  }

  /**
   * Load configuration from JSON file
   */
  loadConfig() {
    try {
      if (!fs.existsSync(this.configPath)) {
        throw new Error(`Configuration file not found: ${this.configPath}`);
      }

      const configData = fs.readFileSync(this.configPath, 'utf8');
      const config = JSON.parse(configData);
      
      console.log(`✅ Configuration loaded from: ${this.configPath}`);
      return config;
      
    } catch (error) {
      console.error('❌ Failed to load configuration:', error.message);
      throw error;
    }
  }

  /**
   * Validate configuration structure and values
   */
  validateConfig() {
    try {
      // Validate required sections
      const requiredSections = ['area', 'grid', 'processing', 'ndvi', 'sensor', 'output'];
      for (const section of requiredSections) {
        if (!this.config[section]) {
          throw new Error(`Missing required configuration section: ${section}`);
        }
      }

      // Validate area configuration
      this.validateAreaConfig();
      
      // Validate NDVI configuration
      this.validateNDVIConfig();
      
      // Validate sensor configuration
      this.validateSensorConfig();
      
      // Validate processing configuration
      this.validateProcessingConfig();
      
      console.log('✅ Configuration validation passed');
      
    } catch (error) {
      console.error('❌ Configuration validation failed:', error.message);
      throw error;
    }
  }

  /**
   * Validate area configuration
   */
  validateAreaConfig() {
    const area = this.config.area;
    
    if (!area.name || typeof area.name !== 'string') {
      throw new Error('Area name must be a non-empty string');
    }
    
    // Handle both legacy polygon format and new GeoJSON format
    if (area.type === 'geojson') {
      this.validateGeoJSONArea(area);
    } else if (area.polygon) {
      this.validatePolygonArea(area);
    } else {
      throw new Error('Area must contain either "polygon" or "geojson" field');
    }
  }

  /**
   * Validate GeoJSON area configuration
   */
  validateGeoJSONArea(area) {
    if (!area.geojson || typeof area.geojson !== 'object') {
      throw new Error('GeoJSON area must contain a valid geojson object');
    }
    
    const geojson = area.geojson;
    
    if (geojson.type !== 'FeatureCollection') {
      throw new Error('GeoJSON type must be "FeatureCollection"');
    }
    
    if (!Array.isArray(geojson.features) || geojson.features.length === 0) {
      throw new Error('GeoJSON must contain at least one feature');
    }
    
    // Validate each feature
    geojson.features.forEach((feature, index) => {
      if (feature.type !== 'Feature') {
        throw new Error(`Feature ${index} must have type "Feature"`);
      }
      
      if (!feature.geometry || feature.geometry.type !== 'Polygon') {
        throw new Error(`Feature ${index} must have a Polygon geometry`);
      }
      
      const coordinates = feature.geometry.coordinates;
      if (!Array.isArray(coordinates) || coordinates.length === 0) {
        throw new Error(`Feature ${index} polygon coordinates must be an array`);
      }
      
      // Validate the first (exterior) ring
      const exteriorRing = coordinates[0];
      if (!Array.isArray(exteriorRing) || exteriorRing.length < 4) {
        throw new Error(`Feature ${index} polygon must have at least 4 coordinate pairs`);
      }
      
      // Validate coordinate pairs
      exteriorRing.forEach((coord, coordIndex) => {
        if (!Array.isArray(coord) || coord.length !== 2) {
          throw new Error(`Feature ${index} coordinate ${coordIndex} must be [longitude, latitude]`);
        }
        
        const [lng, lat] = coord;
        if (typeof lng !== 'number' || typeof lat !== 'number') {
          throw new Error(`Feature ${index} coordinate ${coordIndex} must contain numbers`);
        }
        
        if (lng < -180 || lng > 180 || lat < -90 || lat > 90) {
          throw new Error(`Feature ${index} coordinate ${coordIndex} out of valid range`);
        }
      });
    });
    
    // Validate maxAreaKm2 if present
    if (area.maxAreaKm2 && (typeof area.maxAreaKm2 !== 'number' || area.maxAreaKm2 <= 0)) {
      throw new Error('maxAreaKm2 must be a positive number');
    }
  }

  /**
   * Validate legacy polygon area configuration
   */
  validatePolygonArea(area) {
    if (!Array.isArray(area.polygon) || area.polygon.length < 3) {
      throw new Error('Area polygon must be an array with at least 3 coordinate pairs');
    }
    
    // Validate polygon coordinates
    for (let i = 0; i < area.polygon.length; i++) {
      const coord = area.polygon[i];
      if (!Array.isArray(coord) || coord.length !== 2) {
        throw new Error(`Invalid coordinate at polygon[${i}]: must be [longitude, latitude]`);
      }
      
      const [lng, lat] = coord;
      if (typeof lng !== 'number' || typeof lat !== 'number') {
        throw new Error(`Invalid coordinate at polygon[${i}]: coordinates must be numbers`);
      }
      
      if (lng < -180 || lng > 180 || lat < -90 || lat > 90) {
        throw new Error(`Invalid coordinate at polygon[${i}]: out of valid range`);
      }
    }
  }

  /**
   * Validate NDVI configuration
   */
  validateNDVIConfig() {
    const ndvi = this.config.ndvi;
    
    // Validate required fields
    const requiredFields = ['cloudThreshold', 'scale', 'satellite', 'bands'];
    for (const field of requiredFields) {
      if (ndvi[field] === undefined) {
        throw new Error(`Missing required NDVI field: ${field}`);
      }
    }
    
    // Validate cloud threshold
    if (ndvi.cloudThreshold < 0 || ndvi.cloudThreshold > 100) {
      throw new Error('NDVI cloudThreshold must be between 0 and 100');
    }
    
    // Validate scale
    if (ndvi.scale <= 0) {
      throw new Error('NDVI scale must be positive');
    }
    
    // Validate satellite
    const validSatellites = ['LANDSAT_8', 'LANDSAT_9', 'SENTINEL_2', 'COPERNICUS/S2_SR'];
    if (!validSatellites.includes(ndvi.satellite)) {
      throw new Error(`Invalid satellite: ${ndvi.satellite}. Must be one of: ${validSatellites.join(', ')}`);
    }
    
    // Validate bands
    if (!Array.isArray(ndvi.bands) || ndvi.bands.length === 0) {
      throw new Error('NDVI bands must be a non-empty array');
    }
  }

  /**
   * Validate sensor configuration
   */
  validateSensorConfig() {
    const sensor = this.config.sensor;
    
    // Validate required fields
    if (!sensor.assets || typeof sensor.assets !== 'object') {
      throw new Error('Sensor assets must be an object');
    }
    
    // Validate that we have exactly 5 sensors for 20 bands (4 each)
    const requiredSensors = ['ECe', 'N', 'P', 'pH', 'OC'];
    for (const sensorName of requiredSensors) {
      if (!sensor.assets[sensorName]) {
        throw new Error(`Missing required sensor asset: ${sensorName}`);
      }
      
      if (typeof sensor.assets[sensorName] !== 'string') {
        throw new Error(`Sensor asset ${sensorName} must be a string`);
      }
    }
    
    // Validate band configuration
    if (sensor.bandConfiguration) {
      for (const sensorName of requiredSensors) {
        const bandConfig = sensor.bandConfiguration[sensorName];
        if (bandConfig && bandConfig.bands) {
          if (!Array.isArray(bandConfig.bands) || bandConfig.bands.length !== 4) {
            throw new Error(`Sensor ${sensorName} must have exactly 4 bands configured`);
          }
        }
      }
    }
    
    // Validate scale
    if (sensor.scale <= 0) {
      throw new Error('Sensor scale must be positive');
    }
  }

  /**
   * Validate processing configuration
   */
  validateProcessingConfig() {
    const processing = this.config.processing;
    
    // Validate concurrent cells
    if (processing.concurrentCells && processing.concurrentCells < 1) {
      throw new Error('concurrentCells must be at least 1');
    }
    
    // Validate delays
    if (processing.delayBetweenBatches && processing.delayBetweenBatches < 0) {
      throw new Error('delayBetweenBatches must be non-negative');
    }
    
    if (processing.delayBetweenCells && processing.delayBetweenCells < 0) {
      throw new Error('delayBetweenCells must be non-negative');
    }
  }

  /**
   * Get configuration value by path (dot notation)
   */
  get(path) {
    return this.getNestedValue(this.config, path);
  }

  /**
   * Set configuration value by path (dot notation)
   */
  set(path, value) {
    this.setNestedValue(this.config, path, value);
  }

  /**
   * Get nested value using dot notation
   */
  getNestedValue(obj, path) {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : undefined;
    }, obj);
  }

  /**
   * Set nested value using dot notation
   */
  setNestedValue(obj, path, value) {
    const keys = path.split('.');
    const lastKey = keys.pop();
    const target = keys.reduce((current, key) => {
      if (!current[key] || typeof current[key] !== 'object') {
        current[key] = {};
      }
      return current[key];
    }, obj);
    target[lastKey] = value;
  }

  /**
   * Get area information
   */
  getAreaInfo() {
    const area = this.config.area;
    
    if (area.type === 'geojson') {
      return {
        name: area.name,
        type: 'geojson',
        geojson: area.geojson,
        maxAreaKm2: area.maxAreaKm2 || 50
      };
    } else {
      return {
        name: area.name,
        type: 'polygon',
        polygon: area.polygon
      };
    }
  }

  /**
   * Get all polygons from area configuration
   */
  getPolygons() {
    const area = this.config.area;
    
    if (area.type === 'geojson') {
      return area.geojson.features.map(feature => 
        feature.geometry.coordinates[0] // Extract exterior ring
      );
    } else {
      return [area.polygon];
    }
  }

  /**
   * Get NDVI configuration
   */
  getNDVIConfig() {
    return this.config.ndvi;
  }

  /**
   * Get sensor configuration
   */
  getSensorConfig() {
    return this.config.sensor;
  }

  /**
   * Get processing configuration
   */
  getProcessingConfig() {
    return this.config.processing;
  }

  /**
   * Get performance configuration
   */
  getPerformanceConfig() {
    return this.config.performance || {
      enableBatching: true,
      batchSize: 2,
      enableCache: true,
      cacheTimeout: 600000
    };
  }

  /**
   * Get output configuration
   */
  getOutputConfig() {
    return this.config.output;
  }

  /**
   * Create output directory structure
   */
  createOutputStructure() {
    try {
      const baseDir = this.config.output.baseDir;
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      
      let outputDir;
      if (this.config.output.createTimestampedFolder) {
        outputDir = path.join(baseDir, `${this.config.area.name}_${timestamp}`);
      } else {
        outputDir = path.join(baseDir, this.config.area.name);
      }
      
      // Create directory if it doesn't exist
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }
      
      return outputDir;
      
    } catch (error) {
      console.error('❌ Failed to create output directory:', error.message);
      throw error;
    }
  }

  /**
   * Get the full configuration object
   */
  getFullConfig() {
    return { ...this.config };
  }

  /**
   * Save current configuration to file
   */
  saveConfig(outputPath = null) {
    try {
      const savePath = outputPath || this.configPath;
      fs.writeFileSync(savePath, JSON.stringify(this.config, null, 2));
      console.log(`✅ Configuration saved to: ${savePath}`);
    } catch (error) {
      console.error('❌ Failed to save configuration:', error.message);
      throw error;
    }
  }
}

module.exports = ConfigManager;