/**
 * Progress Tracker Module for Test15
 * Handles progress tracking, timing, and performance monitoring
 */

class ProgressTracker {
  constructor(totalCells) {
    this.totalCells = totalCells;
    this.startTime = Date.now();
    this.cells = {};
    this.batches = [];
    this.currentBatch = null;
    this.stats = {
      completed: 0,
      failed: 0,
      skipped: 0,
      totalNDVIDownloads: 0,
      totalSensorDownloads: 0,
      totalDataMB: 0,
      totalProcessingTime: 0
    };
  }

  /**
   * Start batch processing
   */
  startBatch(batchNumber, batchSize) {
    this.currentBatch = {
      number: batchNumber,
      size: batchSize,
      startTime: Date.now(),
      cells: [],
      completed: 0,
      failed: 0
    };
    
    console.log(`🔄 Starting batch ${batchNumber} (${batchSize} cells)`);
  }

  /**
   * Complete batch processing
   */
  completeBatch() {
    if (this.currentBatch) {
      this.currentBatch.endTime = Date.now();
      this.currentBatch.duration = this.currentBatch.endTime - this.currentBatch.startTime;
      this.batches.push({ ...this.currentBatch });
      
      const minutes = (this.currentBatch.duration / 1000 / 60).toFixed(1);
      console.log(`✅ Batch ${this.currentBatch.number} completed in ${minutes} minutes`);
      
      this.currentBatch = null;
    }
  }

  /**
   * Start cell processing
   */
  startCell(cellId) {
    const cellTracker = {
      cellId: cellId,
      startTime: Date.now(),
      ndviDownload: null,
      sensorDownload: null,
      status: 'processing'
    };
    
    this.cells[cellId] = cellTracker;
    
    if (this.currentBatch) {
      this.currentBatch.cells.push(cellId);
    }
    
    return cellTracker;
  }

  /**
   * Complete cell processing
   */
  completeCell(cellTracker, success, errorMessage = null) {
    if (!cellTracker) return;
    
    cellTracker.endTime = Date.now();
    cellTracker.duration = cellTracker.endTime - cellTracker.startTime;
    cellTracker.status = success ? 'completed' : 'failed';
    cellTracker.error = errorMessage;
    
    // Update statistics
    if (success) {
      this.stats.completed++;
      this.stats.totalProcessingTime += cellTracker.duration;
      
      if (this.currentBatch) {
        this.currentBatch.completed++;
      }
    } else {
      this.stats.failed++;
      
      if (this.currentBatch) {
        this.currentBatch.failed++;
      }
    }
  }

  /**
   * Skip cell processing
   */
  skipCell(cellId) {
    this.stats.skipped++;
    
    if (this.cells[cellId]) {
      this.cells[cellId].status = 'skipped';
      this.cells[cellId].endTime = Date.now();
      this.cells[cellId].duration = this.cells[cellId].endTime - this.cells[cellId].startTime;
    }
  }

  /**
   * Start NDVI download
   */
  startNDVIDownload(cellTracker) {
    if (!cellTracker) return;
    
    cellTracker.ndviDownload = {
      startTime: Date.now(),
      status: 'downloading'
    };
  }

  /**
   * Complete NDVI download
   */
  completeNDVIDownload(cellTracker, success, fileSize = 0) {
    if (!cellTracker || !cellTracker.ndviDownload) return;
    
    cellTracker.ndviDownload.endTime = Date.now();
    cellTracker.ndviDownload.duration = cellTracker.ndviDownload.endTime - cellTracker.ndviDownload.startTime;
    cellTracker.ndviDownload.status = success ? 'completed' : 'failed';
    cellTracker.ndviDownload.fileSize = fileSize;
    
    if (success) {
      this.stats.totalNDVIDownloads++;
      this.stats.totalDataMB += fileSize;
    }
  }

  /**
   * Start sensor download
   */
  startSensorDownload(cellTracker) {
    if (!cellTracker) return;
    
    cellTracker.sensorDownload = {
      startTime: Date.now(),
      status: 'downloading'
    };
  }

  /**
   * Complete sensor download
   */
  completeSensorDownload(cellTracker, success, fileSize = 0) {
    if (!cellTracker || !cellTracker.sensorDownload) return;
    
    cellTracker.sensorDownload.endTime = Date.now();
    cellTracker.sensorDownload.duration = cellTracker.sensorDownload.endTime - cellTracker.sensorDownload.startTime;
    cellTracker.sensorDownload.status = success ? 'completed' : 'failed';
    cellTracker.sensorDownload.fileSize = fileSize;
    
    if (success) {
      this.stats.totalSensorDownloads++;
      this.stats.totalDataMB += fileSize;
    }
  }

  /**
   * Print current progress
   */
  printProgress() {
    const totalProcessed = this.stats.completed + this.stats.failed + this.stats.skipped;
    const progressPercent = ((totalProcessed / this.totalCells) * 100).toFixed(1);
    const elapsedMinutes = ((Date.now() - this.startTime) / 1000 / 60).toFixed(1);
    
    console.log(`\n📊 Progress: ${totalProcessed}/${this.totalCells} cells (${progressPercent}%)`);
    console.log(`   ✅ Completed: ${this.stats.completed}`);
    console.log(`   ❌ Failed: ${this.stats.failed}`);
    console.log(`   ⏭️  Skipped: ${this.stats.skipped}`);
    console.log(`   ⏱️  Elapsed: ${elapsedMinutes} minutes`);
    console.log(`   📦 Data: ${this.stats.totalDataMB.toFixed(1)} MB`);
    
    // Estimate remaining time
    if (this.stats.completed > 0) {
      const avgTimePerCell = this.stats.totalProcessingTime / this.stats.completed;
      const remainingCells = this.totalCells - totalProcessed;
      const estimatedRemainingMinutes = (remainingCells * avgTimePerCell / 1000 / 60).toFixed(1);
      
      if (remainingCells > 0) {
        console.log(`   🔮 Estimated remaining: ${estimatedRemainingMinutes} minutes`);
      }
    }
  }

  /**
   * Print batch progress
   */
  printBatchProgress() {
    if (!this.currentBatch) return;
    
    const batchProcessed = this.currentBatch.completed + this.currentBatch.failed;
    const batchPercent = ((batchProcessed / this.currentBatch.size) * 100).toFixed(1);
    const batchElapsed = ((Date.now() - this.currentBatch.startTime) / 1000 / 60).toFixed(1);
    
    console.log(`   📊 Batch ${this.currentBatch.number}: ${batchProcessed}/${this.currentBatch.size} (${batchPercent}%) in ${batchElapsed}min`);
  }

  /**
   * Get detailed statistics
   */
  getDetailedStats() {
    const totalTime = Date.now() - this.startTime;
    const totalProcessed = this.stats.completed + this.stats.failed + this.stats.skipped;
    
    const stats = {
      // Basic counts
      totalCells: this.totalCells,
      completed: this.stats.completed,
      failed: this.stats.failed,
      skipped: this.stats.skipped,
      totalProcessed: totalProcessed,
      
      // Success rate
      successRate: this.totalCells > 0 ? (this.stats.completed / this.totalCells) * 100 : 0,
      
      // Timing
      totalTimeMs: totalTime,
      totalTimeMinutes: totalTime / 1000 / 60,
      avgProcessingTimeMs: this.stats.completed > 0 ? this.stats.totalProcessingTime / this.stats.completed : 0,
      
      // Performance
      cellsPerMinute: this.stats.completed > 0 ? (this.stats.completed / (totalTime / 1000 / 60)) : 0,
      
      // Data
      totalDataMB: parseFloat(this.stats.totalDataMB.toFixed(2)),
      avgDataPerCellMB: this.stats.completed > 0 ? this.stats.totalDataMB / this.stats.completed : 0,
      totalNDVIDownloads: this.stats.totalNDVIDownloads,
      totalSensorDownloads: this.stats.totalSensorDownloads,
      
      // Batch information
      totalBatches: this.batches.length,
      batchStats: this.getBatchStats()
    };
    
    return stats;
  }

  /**
   * Get batch statistics
   */
  getBatchStats() {
    if (this.batches.length === 0) {
      return { available: false };
    }
    
    const batchDurations = this.batches.map(batch => batch.duration);
    const batchSizes = this.batches.map(batch => batch.size);
    const batchCompletions = this.batches.map(batch => batch.completed);
    
    return {
      available: true,
      totalBatches: this.batches.length,
      avgBatchDurationMs: batchDurations.reduce((a, b) => a + b, 0) / batchDurations.length,
      minBatchDurationMs: Math.min(...batchDurations),
      maxBatchDurationMs: Math.max(...batchDurations),
      avgBatchSize: batchSizes.reduce((a, b) => a + b, 0) / batchSizes.length,
      avgBatchCompletion: batchCompletions.reduce((a, b) => a + b, 0) / batchCompletions.length
    };
  }

  /**
   * Get cell performance analysis
   */
  getCellPerformanceAnalysis() {
    const cellStats = Object.values(this.cells).filter(cell => cell.status === 'completed');
    
    if (cellStats.length === 0) {
      return { available: false, reason: 'No completed cells to analyze' };
    }
    
    const durations = cellStats.map(cell => cell.duration);
    const ndviDownloadTimes = cellStats
      .filter(cell => cell.ndviDownload && cell.ndviDownload.duration)
      .map(cell => cell.ndviDownload.duration);
    const sensorDownloadTimes = cellStats
      .filter(cell => cell.sensorDownload && cell.sensorDownload.duration)
      .map(cell => cell.sensorDownload.duration);
    
    return {
      available: true,
      totalCells: cellStats.length,
      
      // Overall processing times
      avgProcessingTimeMs: durations.reduce((a, b) => a + b, 0) / durations.length,
      minProcessingTimeMs: Math.min(...durations),
      maxProcessingTimeMs: Math.max(...durations),
      
      // NDVI download times
      ndviDownloads: {
        count: ndviDownloadTimes.length,
        avgTimeMs: ndviDownloadTimes.length > 0 ? ndviDownloadTimes.reduce((a, b) => a + b, 0) / ndviDownloadTimes.length : 0,
        minTimeMs: ndviDownloadTimes.length > 0 ? Math.min(...ndviDownloadTimes) : 0,
        maxTimeMs: ndviDownloadTimes.length > 0 ? Math.max(...ndviDownloadTimes) : 0
      },
      
      // Sensor download times
      sensorDownloads: {
        count: sensorDownloadTimes.length,
        avgTimeMs: sensorDownloadTimes.length > 0 ? sensorDownloadTimes.reduce((a, b) => a + b, 0) / sensorDownloadTimes.length : 0,
        minTimeMs: sensorDownloadTimes.length > 0 ? Math.min(...sensorDownloadTimes) : 0,
        maxTimeMs: sensorDownloadTimes.length > 0 ? Math.max(...sensorDownloadTimes) : 0
      }
    };
  }

  /**
   * Get failed cells analysis
   */
  getFailedCellsAnalysis() {
    const failedCells = Object.values(this.cells).filter(cell => cell.status === 'failed');
    
    if (failedCells.length === 0) {
      return { available: false, reason: 'No failed cells' };
    }
    
    const errorTypes = {};
    for (const cell of failedCells) {
      if (cell.error) {
        const errorType = this.categorizeError(cell.error);
        errorTypes[errorType] = (errorTypes[errorType] || 0) + 1;
      }
    }
    
    return {
      available: true,
      totalFailed: failedCells.length,
      errorTypes: errorTypes,
      failureRate: (failedCells.length / this.totalCells) * 100
    };
  }

  /**
   * Categorize error types
   */
  categorizeError(errorMessage) {
    const message = errorMessage.toLowerCase();
    
    if (message.includes('timeout') || message.includes('timed out')) {
      return 'timeout';
    } else if (message.includes('network') || message.includes('connection')) {
      return 'network';
    } else if (message.includes('no') && message.includes('image')) {
      return 'no_data';
    } else if (message.includes('download') || message.includes('url')) {
      return 'download_error';
    } else if (message.includes('permission') || message.includes('access')) {
      return 'permission_error';
    } else if (message.includes('quota') || message.includes('limit')) {
      return 'quota_exceeded';
    } else {
      return 'other';
    }
  }

  /**
   * Export progress data to JSON
   */
  exportProgressData(filepath) {
    try {
      const data = {
        summary: this.getDetailedStats(),
        performance: this.getCellPerformanceAnalysis(),
        failures: this.getFailedCellsAnalysis(),
        batches: this.batches,
        cells: this.cells,
        exportTime: new Date().toISOString()
      };
      
      const fs = require('fs');
      fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
      
      return { success: true, filepath: filepath };
      
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Create performance report
   */
  createPerformanceReport() {
    const stats = this.getDetailedStats();
    const performance = this.getCellPerformanceAnalysis();
    const failures = this.getFailedCellsAnalysis();
    
    const report = {
      title: 'Test15 Performance Report',
      timestamp: new Date().toISOString(),
      
      summary: {
        totalCells: stats.totalCells,
        successRate: `${stats.successRate.toFixed(1)}%`,
        totalTime: `${stats.totalTimeMinutes.toFixed(1)} minutes`,
        avgTimePerCell: `${(stats.avgProcessingTimeMs / 1000).toFixed(1)} seconds`,
        throughput: `${stats.cellsPerMinute.toFixed(1)} cells/minute`,
        totalData: `${stats.totalDataMB} MB`
      },
      
      performance: performance.available ? {
        avgProcessingTime: `${(performance.avgProcessingTimeMs / 1000).toFixed(1)}s`,
        ndviAvgDownloadTime: `${(performance.ndviDownloads.avgTimeMs / 1000).toFixed(1)}s`,
        sensorAvgDownloadTime: `${(performance.sensorDownloads.avgTimeMs / 1000).toFixed(1)}s`
      } : 'Not available',
      
      failures: failures.available ? {
        totalFailed: failures.totalFailed,
        failureRate: `${failures.failureRate.toFixed(1)}%`,
        errorTypes: failures.errorTypes
      } : 'No failures'
    };
    
    return report;
  }
}

module.exports = ProgressTracker;