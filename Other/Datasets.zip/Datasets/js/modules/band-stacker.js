/**
 * Band Stacker Module for Test15
 * Handles combining NDVI and sensor data into single multi-band images
 */

const ee = require('@google/earthengine');
const path = require('path');
const fs = require('fs');

class BandStacker {
  constructor(config, earthEngine) {
    this.config = config;
    this.ee = earthEngine;
    this.bandStackingConfig = config.get('output.bandStacking');
  }

  /**
   * Combine NDVI and sensor data into a single 21-band image
   */
  async createStackedNDVISensorImage(cell, ndviCollection, sensorImages) {
    try {
      console.log(`   🔗 Creating 21-band stacked NDVI+Sensor image for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const targetResolution = this.bandStackingConfig.targetResolution;
      const resamplingMethod = this.bandStackingConfig.resamplingMethod;
      
      // Get NDVI image (1 band at specified resolution)
      const ndviImage = await this.prepareNDVIImage(ndviCollection, region);
      console.log(`   ✅ NDVI image prepared: 1 band at ${targetResolution}m`);
      
      // Get sensor image (20 bands at 1000m, need upsampling to target resolution)
      const sensorImage = await this.prepareSensorImage(sensorImages, region, targetResolution, resamplingMethod);
      console.log(`   ✅ Sensor image prepared: 20 bands upsampled to ${targetResolution}m`);
      
      // Combine images
      const stackedImage = this.combineNDVISensorImages(ndviImage, sensorImage);
      console.log(`   ✅ Images combined: 21 bands total (1 NDVI + 20 Sensor)`);
      
      return stackedImage;
      
    } catch (error) {
      console.error(`   ❌ NDVI+Sensor band stacking failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Prepare NDVI image with proper band selection and naming
   */
  async prepareNDVIImage(ndviCollection, region) {
    try {
      // Create median NDVI composite
      const ndviComposite = this.ee.createNDVIMedianComposite(ndviCollection, region);
      
      // Ensure NDVI band is named correctly
      const processedNDVI = ndviComposite.select('NDVI').rename('NDVI');
      
      return processedNDVI;
      
    } catch (error) {
      throw new Error(`Failed to prepare NDVI image: ${error.message}`);
    }
  }

  /**
   * Prepare sensor image with upsampling to target resolution
   */
  async prepareSensorImage(sensorImages, region, targetResolution, resamplingMethod) {
    const sensorConfig = this.config.get('sensor');
    
    // Load and combine all sensor assets
    const validSensors = [];
    
    for (const [sensorName, assetId] of Object.entries(sensorConfig.assets)) {
      try {
        console.log(`     📊 Loading ${sensorName} sensor for stacking...`);
        
        const sensorImage = this.ee.getSensorImage(assetId);
        const imageInfo = await this.ee.getImageInfo(sensorImage);
        
        // Get band configuration
        const bandConfig = sensorConfig.bandConfiguration[sensorName];
        let bandNames;
        
        if (bandConfig && bandConfig.bands) {
          bandNames = bandConfig.bands;
        } else {
          // Default to 4 bands per sensor
          bandNames = [`${sensorName}_mean`, `${sensorName}_median`, `${sensorName}_std`, `${sensorName}_max`];
        }
        
        // Ensure we have exactly 4 bands per sensor
        if (imageInfo.bands.length < 4) {
          console.warn(`     ⚠️ ${sensorName} has only ${imageInfo.bands.length} bands, expected 4`);
          // Pad with repeated bands if necessary
          while (bandNames.length < 4) {
            bandNames.push(`${sensorName}_band${bandNames.length + 1}`);
          }
        }
        
        // Take only first 4 bands
        bandNames = bandNames.slice(0, 4);
        
        const renamedImage = sensorImage.select(
          imageInfo.bands.slice(0, 4).map(band => band.id),
          bandNames
        );
        
        validSensors.push(renamedImage);
        
        console.log(`     ✅ ${sensorName}: 4 bands loaded (${bandNames.join(', ')})`);
        
      } catch (error) {
        console.warn(`     ⚠️ Failed to load ${sensorName}: ${error.message}`);
        continue;
      }
    }
    
    if (validSensors.length === 0) {
      throw new Error('No sensor data could be loaded for stacking');
    }
    
    if (validSensors.length < 5) {
      console.warn(`     ⚠️ Only ${validSensors.length}/5 sensors loaded successfully`);
    }
    
    // Combine all sensor images
    const combinedSensorImage = ee.Image.cat(validSensors);
    
    // Upsample to target resolution using reprojection
    const upsampledImage = combinedSensorImage.reproject({
      crs: 'EPSG:4326',
      scale: targetResolution
    }).resample(resamplingMethod);
    
    console.log(`     🔍 Upsampled sensor data from 1000m to ${targetResolution}m`);
    
    return upsampledImage.clip(region);
  }

  /**
   * Combine NDVI and sensor images into final stack
   */
  combineNDVISensorImages(ndviImage, sensorImage) {
    const bandOrder = this.bandStackingConfig.bandOrder;
    
    let finalImage;
    
    if (bandOrder[0] === 'ndvi') {
      // NDVI band first (1), then sensor bands (2-21)
      finalImage = ee.Image.cat([ndviImage, sensorImage]);
    } else {
      // Sensor bands first (1-20), then NDVI band (21)
      finalImage = ee.Image.cat([sensorImage, ndviImage]);
    }
    
    return finalImage;
  }

  /**
   * Download stacked image as single .tif file with fixed pixel dimensions
   */
  async downloadStackedImage(stackedImage, cell, outputDir) {
    try {
      console.log(`   📥 Downloading 21-band stacked NDVI+Sensor image...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const fixedPixelConfig = this.bandStackingConfig.fixedPixelDimensions;
      
      // Always clip the image to the region first
      const clippedImage = stackedImage.clip(region);
      
      let downloadParams;
      
      if (fixedPixelConfig && fixedPixelConfig.enabled) {
        // Use fixed pixel dimensions - clip first, then set dimensions
        const width = fixedPixelConfig.width;
        const height = fixedPixelConfig.enforceSquare ? width : fixedPixelConfig.height;
        
        console.log(`   🖼️  Using fixed dimensions: ${width}x${height} pixels`);
        
        downloadParams = {
          dimensions: [width, height],
          crs: 'EPSG:4326',
          format: this.bandStackingConfig.outputFormat,
          formatOptions: {
            cloudOptimized: true,
            noData: this.bandStackingConfig.noDataValue
          }
        };
      } else {
        // Use scale-based dimensions (original behavior)
        downloadParams = {
          scale: this.bandStackingConfig.targetResolution,
          region: region,
          maxPixels: this.config.get('ndvi.maxPixels'),
          format: this.bandStackingConfig.outputFormat,
          formatOptions: {
            cloudOptimized: true,
            noData: this.bandStackingConfig.noDataValue
          }
        };
      }
      
      // Get download URL using the clipped image for fixed dimensions, or original for scale-based
      const imageToDownload = fixedPixelConfig && fixedPixelConfig.enabled ? clippedImage : stackedImage;
      const downloadUrl = await this.ee.getDownloadUrl(imageToDownload, downloadParams);
      
      if (!downloadUrl) {
        throw new Error('Failed to generate stacked NDVI+Sensor image download URL');
      }
      
      console.log('   ✅ Stacked NDVI+Sensor image download URL generated');
      
      // Download file
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `${this.config.get('area.name')}_ndvi_sensor_21bands_${timestamp}.tif`;
      const filepath = path.join(outputDir, filename);
      
      console.log(`   📥 Downloading to: ${filename}`);
      await this.downloadFile(downloadUrl, filepath);
      
      const stats = fs.statSync(filepath);
      const fileSizeMB = stats.size / (1024 * 1024);
      
      console.log(`   ✅ Stacked NDVI+Sensor image download completed: ${fileSizeMB.toFixed(2)} MB`);
      
      // Generate band information
      const bands = this.generateBandInfo();
      
      return {
        success: true,
        filepath: filepath,
        filename: filename,
        fileSize: fileSizeMB,
        totalBands: 21,
        bands: bands,
        type: 'stacked_ndvi_sensor'
      };
      
    } catch (error) {
      console.error(`   ❌ Stacked NDVI+Sensor image download failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Generate comprehensive band information
   */
  generateBandInfo() {
    const sensorConfig = this.config.get('sensor');
    const bandOrder = this.bandStackingConfig.bandOrder;
    const bands = [];
    
    if (bandOrder[0] === 'ndvi') {
      // NDVI first
      bands.push({
        bandNumber: 1,
        name: 'NDVI',
        description: 'Normalized Difference Vegetation Index',
        type: 'vegetation',
        range: '-1 to 1',
        resolution: `${this.bandStackingConfig.targetResolution}m`
      });
      
      // Then sensor bands
      let bandNumber = 2;
      for (const [sensorName, assetId] of Object.entries(sensorConfig.assets)) {
        const bandConfig = sensorConfig.bandConfiguration[sensorName];
        const validation = sensorConfig.validation[sensorName];
        
        const sensorBands = bandConfig ? bandConfig.bands : 
          [`${sensorName}_mean`, `${sensorName}_median`, `${sensorName}_std`, `${sensorName}_max`];
        
        for (const bandName of sensorBands.slice(0, 4)) {
          bands.push({
            bandNumber: bandNumber,
            name: bandName,
            description: `${sensorName} - ${bandConfig ? bandConfig.description : 'Sensor data'}`,
            type: 'sensor',
            unit: validation ? validation.unit : 'unknown',
            range: validation ? `${validation.min} to ${validation.max}` : 'unknown',
            resolution: `${this.bandStackingConfig.targetResolution}m (upsampled from 1000m)`
          });
          bandNumber++;
        }
      }
    } else {
      // Sensor bands first
      let bandNumber = 1;
      for (const [sensorName, assetId] of Object.entries(sensorConfig.assets)) {
        const bandConfig = sensorConfig.bandConfiguration[sensorName];
        const validation = sensorConfig.validation[sensorName];
        
        const sensorBands = bandConfig ? bandConfig.bands : 
          [`${sensorName}_mean`, `${sensorName}_median`, `${sensorName}_std`, `${sensorName}_max`];
        
        for (const bandName of sensorBands.slice(0, 4)) {
          bands.push({
            bandNumber: bandNumber,
            name: bandName,
            description: `${sensorName} - ${bandConfig ? bandConfig.description : 'Sensor data'}`,
            type: 'sensor',
            unit: validation ? validation.unit : 'unknown',
            range: validation ? `${validation.min} to ${validation.max}` : 'unknown',
            resolution: `${this.bandStackingConfig.targetResolution}m (upsampled from 1000m)`
          });
          bandNumber++;
        }
      }
      
      // Then NDVI
      bands.push({
        bandNumber: bandNumber,
        name: 'NDVI',
        description: 'Normalized Difference Vegetation Index',
        type: 'vegetation',
        range: '-1 to 1',
        resolution: `${this.bandStackingConfig.targetResolution}m`
      });
    }
    
    return bands;
  }

  /**
   * Create separate NDVI numpy array export
   */
  async exportNDVIAsNumpy(ndviImage, cell, outputDir) {
    try {
      console.log(`   📊 Exporting NDVI as numpy array for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const ndviConfig = this.config.get('ndvi');
      
      // Export parameters for numpy format
      const downloadUrl = await this.ee.exportNDVIArrayToNumpy(ndviImage, region, ndviConfig.scale);
      
      if (!downloadUrl) {
        throw new Error('Failed to generate NDVI numpy export URL');
      }
      
      // Download numpy file
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `${this.config.get('area.name')}_ndvi_array_${timestamp}.npy`;
      const filepath = path.join(outputDir, filename);
      
      console.log(`   📥 Downloading NDVI numpy array to: ${filename}`);
      await this.downloadFile(downloadUrl, filepath);
      
      const stats = fs.statSync(filepath);
      const fileSizeMB = stats.size / (1024 * 1024);
      
      console.log(`   ✅ NDVI numpy export completed: ${fileSizeMB.toFixed(2)} MB`);
      
      return {
        success: true,
        filepath: filepath,
        filename: filename,
        fileSize: fileSizeMB,
        format: 'numpy',
        type: 'ndvi_array'
      };
      
    } catch (error) {
      console.error(`   ❌ NDVI numpy export failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Generate visualization files (PNG) for stacked data
   */
  async generateVisualization(stackedImage, cell, outputDir) {
    try {
      if (!this.bandStackingConfig.generatePNG || !this.bandStackingConfig.generatePNG.enabled) {
        return null;
      }
      
      console.log(`   🎨 Generating visualization for cell ${cell.id}...`);
      
      const region = this.ee.createGeometry(cell.polygon);
      const visualizations = [];
      
      // Generate NDVI visualization
      if (this.bandStackingConfig.generatePNG.ndviVisualization) {
        const ndviViz = await this.createNDVIVisualization(stackedImage, region, outputDir);
        if (ndviViz) visualizations.push(ndviViz);
      }
      
      // Generate sensor data visualization
      if (this.bandStackingConfig.generatePNG.sensorVisualization) {
        const sensorViz = await this.createSensorVisualization(stackedImage, region, outputDir);
        if (sensorViz) visualizations.push(sensorViz);
      }
      
      return visualizations;
      
    } catch (error) {
      console.warn(`   ⚠️ Visualization generation failed: ${error.message}`);
      return null;
    }
  }

  /**
   * Create NDVI visualization
   */
  async createNDVIVisualization(stackedImage, region, outputDir) {
    // Implementation for NDVI visualization
    // This would create a colored visualization of NDVI values
    return null; // Placeholder
  }

  /**
   * Create sensor data visualization
   */
  async createSensorVisualization(stackedImage, region, outputDir) {
    // Implementation for sensor data visualization
    // This would create visualizations for different sensor parameters
    return null; // Placeholder
  }

  /**
   * Download file from URL
   */
  async downloadFile(url, filepath) {
    const https = require('https');
    
    return new Promise((resolve, reject) => {
      const file = fs.createWriteStream(filepath);
      const timeout = this.config.get('geeConfig.timeout') || 300000; // 5 minutes default
      
      const request = https.get(url, (response) => {
        if (response.statusCode !== 200) {
          reject(new Error(`HTTP ${response.statusCode}: ${response.statusMessage}`));
          return;
        }
        
        response.pipe(file);
        
        file.on('finish', () => {
          file.close();
          resolve();
        });
        
        file.on('error', (error) => {
          fs.unlink(filepath, () => {}); // Delete the file on error
          reject(error);
        });
      });
      
      request.setTimeout(timeout, () => {
        request.abort();
        reject(new Error(`Download timeout after ${timeout}ms`));
      });
      
      request.on('error', (error) => {
        reject(error);
      });
    });
  }
}

module.exports = BandStacker;