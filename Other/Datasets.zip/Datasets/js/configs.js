const end = new Date();  // today
const start = new Date();
start.setMonth(start.getMonth() - 5);  // 2 months before
const CONFIG_NAME_COORDS = {
  name: 'Shikher-7',
farmPolygon:[
        [
            [
              78.0037700240544,
              27.29097276715494
            ],
            [
              78.00440286134858,
              27.29097276715494
            ],
            [
              78.00440286134858,
              27.291403290038375
            ],
            [
              78.0037700240544,
              27.291403290038375
            ],
            [
              78.0037700240544,
              27.29097276715494
            ]
          ]
      ],
  dateRange : {
  start: start.toISOString().split('T')[0], 
  end: end.toISOString().split('T')[0]
},
  cloudThreshold: 50, // Higher threshold to ensure images exist
  imageParams: {
    scale: 10,        // 10m per pixel
    maxPixels: 1e8,   // Higher limit to avoid truncation
    dimensions: null, // Let GEE calculate optimal dimensions
    region: null,     // Will be set from polygon
    
    // CRITICAL: Add explicit format options
    format: 'GEO_TIFF',
    formatOptions: {
      cloudOptimized: true,
      noData: -9999
    }
  }
};

module.exports = {
  CONFIG_NAME_COORDS
};

