// GIVING FARM COORDS AND GETTING FARM PNG IMAGE

const ee = require('@google/earthengine');
const fs = require('fs');
const path = require('path');
const https = require('https');
const { CONFIG_NAME_COORDS } = require('./configs');

// CONFIGURATION - Edit this section only
const CONFIG = {
  name: CONFIG_NAME_COORDS.name,
  farmPolygon: CONFIG_NAME_COORDS.farmPolygon,
  dateRange: CONFIG_NAME_COORDS.dateRange,
  cloudThreshold: CONFIG_NAME_COORDS.cloudThreshold,
  outputDir: './downloaded_images/png/',
  imageParams: {
    scale: CONFIG_NAME_COORDS.imageParams.scale,
    maxPixels: CONFIG_NAME_COORDS.imageParams.maxPixels,
    dimensions: CONFIG_NAME_COORDS.imageParams.dimensions,
    region:CONFIG_NAME_COORDS.imageParams.region,
  }
};
// Initialize Earth Engine
function initializeEE() {
  return new Promise((resolve, reject) => {
    try {
      const privateKeyPath = path.join(__dirname, 'earth-engine-service-account.json');
      
      if (!fs.existsSync(privateKeyPath)) {
        throw new Error(`Service account key not found at: ${privateKeyPath}`);
      }
      
      const privateKey = JSON.parse(fs.readFileSync(privateKeyPath, 'utf8'));
      
      console.log('🔑 Authenticating with Google Earth Engine...');
      
      ee.data.authenticateViaPrivateKey(privateKey, (error) => {
        if (error) {
          reject(new Error(`Authentication failed: ${error}`));
          return;
        }
        
        console.log('✅ Authentication successful!');
        
        ee.initialize(null, null, (initError) => {
          if (initError) {
            reject(new Error(`Initialization failed: ${initError}`));
            return;
          }
          
          console.log('🌍 Google Earth Engine initialized successfully!');
          resolve();
        });
      });
      
    } catch (error) {
      reject(error);
    }
  });
}
// Validate polygon
function validatePolygon(polygon) {
  const issues = [];
  
  if (!Array.isArray(polygon) || polygon.length < 4) {
    issues.push('Polygon must have at least 4 coordinates');
  }
  
  // Check if polygon is closed
  const first = polygon[0];
  const last = polygon[polygon.length - 1];
  if (first[0] !== last[0] || first[1] !== last[1]) {
    issues.push('Polygon must be closed (first and last coordinates should match)');
  }
  
  // Check coordinate format
  polygon.forEach((coord, index) => {
    if (!Array.isArray(coord) || coord.length !== 2) {
      issues.push(`Coordinate ${index} must be [longitude, latitude]`);
    }
    if (Math.abs(coord[0]) > 180 || Math.abs(coord[1]) > 90) {
      issues.push(`Coordinate ${index} has invalid values: [${coord[0]}, ${coord[1]}]`);
    }
  });
  
  return {
    isValid: issues.length === 0,
    issues: issues
  };
}
// Calculate approximate area to warn about large areas
function calculateArea(polygon) {
  // Simple approximation using bounding box
  const lngs = polygon.map(coord => coord[0]);
  const lats = polygon.map(coord => coord[1]);
  
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  
  // Approximate area in degrees squared
  const areaDegrees = (maxLng - minLng) * (maxLat - minLat);
  
  // Convert to approximate hectares (very rough)
  const approximateHectares = areaDegrees * 111 * 111; // rough conversion
  
  return {
    areaDegrees,
    approximateHectares,
    isLarge: approximateHectares > 100 // Warn if > 100 hectares
  };
}

// Download file from URL
function downloadFile(url, filepath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(filepath);
    
    https.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`Download failed with status: ${response.statusCode}`));
        return;
      }
      
      let downloadedBytes = 0;
      const totalBytes = parseInt(response.headers['content-length']) || 0;
      
      response.on('data', (chunk) => {
        downloadedBytes += chunk.length;
        if (totalBytes > 0) {
          const percent = ((downloadedBytes / totalBytes) * 100).toFixed(1);
          process.stdout.write(`\r📥 Downloading: ${percent}% (${(downloadedBytes / 1024 / 1024).toFixed(2)} MB)`);
        }
      });
      
      response.pipe(file);
      
      file.on('finish', () => {
        file.close();
        console.log(`\n✅ Download completed: ${filepath}`);
        resolve();
      });
      
      file.on('error', (error) => {
        fs.unlink(filepath, () => {}); // Delete partial file
        reject(error);
      });
      
    }).on('error', reject);
  });
}

// Main function to download satellite image
async function downloadSatelliteImage() {
  try {
    console.log('🚀 Starting satellite image download...');
    
    // Validate polygon
    const validation = validatePolygon(CONFIG.farmPolygon);
    if (!validation.isValid) {
      console.error('❌ Polygon validation failed:');
      validation.issues.forEach(issue => console.error(`   - ${issue}`));
      throw new Error('Invalid polygon configuration');
    }
    
    // Check area size
    const areaInfo = calculateArea(CONFIG.farmPolygon);
    if (areaInfo.isLarge) {
      console.warn(`⚠️  Large area detected (~${areaInfo.approximateHectares.toFixed(0)} hectares)`);
      console.warn('   This may result in files larger than 5MB');
    }
    
    console.log(`📍 Polygon has ${CONFIG.farmPolygon.length - 1} vertices`);
    
    // Create output directory
    if (!fs.existsSync(CONFIG.outputDir)) {
      fs.mkdirSync(CONFIG.outputDir, { recursive: true });
      console.log(`📁 Created output directory: ${CONFIG.outputDir}`);
    }
    
    // Create geometry
    const region = ee.Geometry.Polygon([CONFIG.farmPolygon]);
    console.log('✅ Polygon geometry created');
    
    console.log('🛰️ Searching for Sentinel-2 imagery...');
    
    // Load Sentinel-2 Surface Reflectance data
    const collection = ee.ImageCollection('COPERNICUS/S2_SR')
    // const collection = ee.ImageCollection('EO1/HYPERION')
      .filterBounds(region)
      .filterDate(CONFIG.dateRange.start, CONFIG.dateRange.end)
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', CONFIG.cloudThreshold))
      .sort('CLOUDY_PIXEL_PERCENTAGE');
    
    // Check available images
    const imageCount = await new Promise((resolve, reject) => {
      collection.size().evaluate((count, error) => {
        if (error) reject(new Error(`Image count failed: ${error}`));
        else resolve(count);
      });
    });
    
    console.log(`📊 Found ${imageCount} suitable images`);
    
    if (imageCount === 0) {
      throw new Error('No suitable images found. Try increasing cloud threshold or expanding date range.');
    }
    
    // Get the best image (median composite clipped to region)
    console.log('🖼️ Creating image composite...');
    const image = collection.median().clip(region);
    
    // Select multispectral bands (B2, B3, B4, B5, B8, B11)
    const multispecImage = image.select(['B2', 'B3', 'B4', 'B5', 'B8', 'B11']);
    
    console.log('📊 Selected bands: B2(Blue), B3(Green), B4(Red), B5(RedEdge), B8(NIR), B11(SWIR)');
    
    // Use Export method instead of getDownloadURL for better compatibility
    console.log('🔗 Preparing image for download...');
    
    // Export to Drive approach (alternative method)
    const exportParams = {
      image: multispecImage,
      description: 'multispectral_export',
      scale: CONFIG.imageParams.scale,
      region: region,
      maxPixels: CONFIG.imageParams.maxPixels,
      fileFormat: 'GeoTIFF',
      formatOptions: {
        cloudOptimized: true
      }
    };
    
    // Try the batch.Export method
    console.log('📤 Starting export task...');
    
    const task = ee.batch.Export.image.toDrive(exportParams);
    
    // For direct download, we'll use a different approach
    // Let's try the REST API approach
    const downloadUrl = `https://earthengine.googleapis.com/v1alpha/projects/${ee.data.getProject()}/image:computePixels`;
    
    // Alternative: Use getThumbURL for smaller images
    const thumbUrl = await new Promise((resolve, reject) => {
      multispecImage.getThumbURL({
        format: 'png',
        bands: ['B4', 'B3', 'B2'], // RGB for thumbnail
        min: 0,
        max: 3000,
        dimensions: 512,
        region: region
      }, (url, error) => {
        if (error) {
          console.log('Thumbnail failed, trying alternative method...');
          resolve(null);
        } else {
          resolve(url);
        }
      });
    });
    
    if (thumbUrl) {
      console.log('📥 Downloading RGB thumbnail (for testing)...');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `${CONFIG.name}-${timestamp}.png`;
      const filepath = path.join(CONFIG.outputDir, filename);
      
      await downloadFile(thumbUrl, filepath);
      
      const stats = fs.statSync(filepath);
      const fileSizeMB = stats.size / (1024 * 1024);
      
      console.log('\n🎉 THUMBNAIL DOWNLOAD COMPLETED!');
      console.log('================================');
      console.log(`File: ${filename}`);
      console.log(`Size: ${fileSizeMB.toFixed(2)} MB`);
      console.log(`Format: PNG (RGB preview)`);
      console.log(`Location: ${filepath}`);
      console.log('\n💡 Note: This is a preview. For full multispectral data,');
      console.log('   you may need to use Google Earth Engine\'s batch export to Drive.');
      
      return {
        success: true,
        filepath: filepath,
        fileSize: fileSizeMB,
        imageCount: imageCount,
        polygon: CONFIG.farmPolygon,
        type: 'thumbnail'
      };
    } else {
      throw new Error('Direct download not available. Please use Earth Engine batch export to Google Drive.');
    }
    
  } catch (error) {
    console.error('❌ Download failed:');
    console.error('Error:', error.message);
    
    console.log('\n💡 Alternative Solutions:');
    console.log('1. Use Earth Engine Code Editor (code.earthengine.google.com)');
    console.log('2. Export to Google Drive using batch processing');
    console.log('3. Use smaller polygon area for direct download');
    
    throw error;
  }
}

// Main execution
async function main() {
  try {
    console.log('🛰️ Satellite Image Downloader');
    console.log('=============================\n');
    
    await initializeEE();
    const result = await downloadSatelliteImage();
    
    console.log('\n✅ Script completed successfully!');
    
  } catch (error) {
    console.error('\n💥 Script failed:');
    console.error('Error:', error.message);
    
    // Provide helpful suggestions
    console.log('\n🔧 Try these solutions:');
    console.log('1. Use smaller polygon area (< 1km x 1km)');
    console.log('2. Increase scale parameter (30-60m)');
    console.log('3. Use Earth Engine Code Editor for larger exports');
    
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGINT', () => { 
  console.log('\n👋 Script interrupted by user');
  process.exit(0);
});

// Run the script
if (require.main === module) {
  main();
}

module.exports = { initializeEE, downloadSatelliteImage };