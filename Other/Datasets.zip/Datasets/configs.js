 const end = new Date();  // today
const start = new Date();
start.setMonth(start.getMonth() - 5);  // 2 months before
const CONFIG_NAME_COORDS = {
  name: 'Shikher-7',
//   farmPolygon: [
//  [ 77.884166,	27.311140],
//  [77.967270,	27.311140],
//  [77.967270,	27.278494],
//  [77.884166,	27.278494],
//  [77.884166,	27.311140]
//   ],
farmPolygon:[
    [
      78.83151272340426,
      28.482211
    ],
    [
      78.91334636170214,
      28.482211
    ],
    [
      78.91334636170214,
      28.540588531914892
    ],
    [
      78.83151272340426,
      28.540588531914892
    ],
    [
      78.83151272340426,
      28.482211
    ]
  ],
  dateRange : {
  start: start.toISOString().split('T')[0], 
  end: end.toISOString().split('T')[0]
},
  cloudThreshold: 50, // Higher threshold to ensure images exist
  imageParams: {
    scale: 10,        // 10m per pixel
    maxPixels: 1e8,   // Higher limit to avoid truncation
    dimensions: null, // Let GEE calculate optimal dimensions
    region: null,     // Will be set from polygon
    
    // CRITICAL: Add explicit format options
    format: 'GEO_TIFF',
    formatOptions: {
      cloudOptimized: true,
      noData: -9999
    }
  }
};


module.exports = {
  CONFIG_NAME_COORDS
};

